# 01 · QUICKSTART（5 分钟上手）

> 给 AI 的入口文件。读完这一页就能开始答题；需要挑技能时再看 `00-ROUTER.md`。

## 0. 先做环境自检（30 秒，必做）

```powershell
python --version
python -c "import importlib.util as u;[print(m, bool(u.find_spec(m))) for m in ['Evtx','pefile','yara','scapy','pyshark','pandas']]"
where.exe tshark; where.exe zeek; where.exe strings; where.exe 7z
```

**为什么要先做**：这类比赛机普遍**没有** tshark / Zeek / Wireshark / Volatility / Ghidra /
YARA / pefile / scapy / pandas。技能里写的命令有一半跑不起来。
先确认，再决定用哪条路径，比写到一半报错省时间。

实测基线（本机，Windows + Python 3.12）：`tshark/zeek/strings/7z/yara/pefile/scapy/pyshark/pandas` **全部缺失**，
可用的是 **Python 标准库 + lxml + requests + pyyaml + python-docx**。

## 1. 装包的正确姿势（沙箱下 pip 会失败）

直接 `pip install X` 会因为沙箱禁止写 pip 缓存目录而报
`[WinError 5] 拒绝访问 ... pip\cache\wheels`。用这个写法：

```powershell
python -m pip install --no-cache-dir --disable-pip-version-check --target vendor python-evtx
```

然后：

```python
import sys; sys.path.insert(0, "vendor")
from Evtx.Evtx import Evtx
```

**判据**：`--no-cache-dir` 绕开被禁的缓存目录，`--target vendor` 把包装进工作区（允许写）。
装完必须显式把 `vendor` 加进 `sys.path`，否则 import 不到。

## 2. 四步法（所有题型通用）

| 步 | 动作 | 产出 | 别做 |
|---|---|---|---|
| 1 盘点 | 列目录、看文件类型/大小/编码、抽样 5 行 | 一句话说明"这是什么数据" | 别一上来就写全量解析 |
| 2 解析 | 先写最小可运行解析器，跑 100 行验证字段名 | 字段清单 | 别假设格式（Zeek 有 TSV 和 JSONL 两种） |
| 3 聚合 | 计数、TopN、时间窗、按实体分组 | 候选异常清单 | 别把原始行直接打印（爆 token） |
| 4 作答 | 每条结论配「文件 + 字段 + 数值」 | JSON / 报告 | 别写没有数字支撑的形容词 |

**铁律**：答案里每个数字都要来自你实际统计的输出，不能是"大约/可能"。

## 3. 缺工具时的兜底表

| 想要 | 没有时用什么 | 现成脚本 |
|---|---|---|
| tshark 看 pcap | Python `struct` 解 pcap + 解 TLS SNI | `toolbox/pcap2flows.py` |
| Zeek 汇总 | 直接读 zeek JSONL | `toolbox/zeek_summary.py` |
| Chainsaw 看 evtx | `pip --target vendor python-evtx` + 正则取字段 | `toolbox/evtx_dump.py` |
| pefile / strings | `struct` 解 PE 头/节表/导入表 + 正则提字符串 | `toolbox/pe_info.py` |
| pandas 聚合 | `collections.Counter` + 生成器 | 手写 10 行 |
| jq / awk | Python 一行流式脚本 | 见 `02-TOOLBOX.md` |

这些脚本都能直接 `python toolbox/xxx.py <文件>` 跑，输出是结构化文本，先看输出再决定深挖哪里。

## 4. 输出契约

比赛要 JSON 时，固定用这个骨架，避免字段名被扣分：

```json
{
  "answers": {"1": "...", "2": "..."},
  "iocs": ["..."],
  "confidence": {"1": "high|medium|low"},
  "evidence": {"1": "文件:行 / 字段=值"}
}
```

- 时间是 **ISO8601 + 时区**（`2020-05-01T22:55:23Z`），不要写"5月1日晚上"。
- 计数写**整数**，不要写"约 376 次"。
- 不知道就写 `null` 并在 `evidence` 说明缺什么，**不要编**。

## 5. 时间盒（按数据量分）

| 数据量 | 给分析的时间 | 做法 |
|---|---|---|
| < 1 万条 | 20 分钟 | 直接读 |
| 1 万–10 万条 | 40 分钟 | 先写解析器，再聚合 |
| > 10 万条 / > 100 MB | 60–90 分钟 | **必须流式**，禁止 `f.read()` 全量入内存 |

先出一页「结论 + 证据矩阵」，再写正文。反过来一定写不完。
