# cybersec-22

来源仓库：`Masriyan__Claude-Code-CyberSecurity-Skill`，共 22 个 skill。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `01-recon-osint` | 317 | 12.7 | Passive and active reconnaissance, subdomain enumeration, DNS analysis, technology fingerprinting, and OSINT d |
| `02-vulnerability-scanner` | 341 | 12.7 | Dependency auditing, CVE detection, configuration security review, CVSS scoring, and prioritized vulnerability |
| `03-exploit-development` | 392 | 14.2 | Proof-of-concept development, payload crafting, shellcode analysis, and exploitation technique research for au |
| `04-reverse-engineering` | 384 | 14.2 | Binary analysis, assembly interpretation, disassembly, decompilation, firmware RE, and protocol reverse engine |
| `05-malware-analysis` | 421 | 15.5 | Static and dynamic malware analysis, YARA rule generation, sandbox configuration, behavioral profiling, and ma |
| `06-threat-hunting` | 434 | 15.0 | IOC extraction, threat intelligence correlation, MITRE ATT&CK mapping, hunt hypothesis generation, and detecti |
| `07-incident-response` | 424 | 15.6 | IR playbook execution, evidence collection, forensic timeline analysis, memory forensics, and post-incident re |
| `08-network-security` | 412 | 13.6 | Network traffic analysis, PCAP parsing, IDS/IPS rule creation, firewall configuration auditing, and network an |
| `09-web-security` | 480 | 15.5 | OWASP Top 10 testing, injection vulnerability detection, API security assessment, authentication testing, and  |
| `10-cloud-security` | 495 | 17.0 | AWS/Azure/GCP security auditing, container and Kubernetes hardening, Infrastructure as Code scanning, and clou |
| `11-csoc-automation` | 485 | 16.4 | SOC alert triage, incident playbook automation, escalation workflows, shift reporting, and SOC KPI tracking |
| `12-log-analysis` | 459 | 16.5 | Security log parsing, anomaly detection, SIEM query building, Sigma rule creation, and correlation rule develo |
| `13-crypto-analysis` | 392 | 15.4 | SSL/TLS auditing, cipher suite analysis, hash algorithm identification, encryption implementation review, and  |
| `14-red-team-ops` | 452 | 16.1 | Authorized red team engagement planning, C2 architecture design, attack methodology, lateral movement strategy |
| `15-blue-team-defense` | 778 | 26.6 | System hardening, detection engineering, security baseline monitoring, patch management, defense-in-depth arch |
| `16-ai-llm-security` | 238 | 12.1 | LLM and AI application security testing — prompt injection, jailbreak resistance, OWASP LLM Top 10 (2025), RAG |
| `17-mobile-security` | 204 | 9.6 | Android and iOS application security testing — static and dynamic analysis, APK/IPA inspection, OWASP MASVS/MA |
| `18-ot-ics-security` | 195 | 9.9 | Operational Technology and industrial control system security — Purdue model segmentation, industrial protocol |
| `19-grc-compliance` | 206 | 9.8 | Governance, risk, and compliance — risk assessment and scoring, control mapping across NIST CSF 2.0 / ISO 2700 |
| `20-supply-chain-security` | 226 | 12.5 | Software supply chain security — SBOM generation and analysis, dependency confusion and typosquatting detectio |
| `21-threat-intelligence` | 237 | 14.8 | Cyber threat intelligence production — the intelligence cycle, IOC extraction/normalization/enrichment, STIX/T |
| `22-purple-team` | 250 | 13.9 | Collaborative purple-team operations — threat-informed adversary emulation planning (ATT&CK, CTID, Atomic Red  |
