# dfir-skills

来源仓库：`Fuzzdkk__dfir-skills`，共 12 个 skill。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `alert` | 216 | 7.2 | SOC alert triage and investigation guidance. Paste an alert description and observables to get structured inve |
| `dfir-report` | 232 | 6.7 | Generate a comprehensive DFIR incident report by consolidating findings from all analysis skills (memory, disk |
| `disk-forensics` | 216 | 5.9 | Analyze disk images and filesystem artifacts using Sleuthkit (mmls, fls, icat), binwalk, strings, and bulk_ext |
| `evidence-acquisition` | 257 | 7.9 | Acquire and preserve digital evidence following forensic best practices. Disk imaging, memory capture, log col |
| `ioc-extract` | 199 | 4.8 | Extract, deduplicate, and classify Indicators of Compromise (IOCs) from any evidence source — files, logs, mem |
| `log-analysis` | 214 | 6.8 | Analyze system and security logs (auth.log, syslog, Windows EVTX, Apache/Nginx, JSON logs). Detect brute force |
| `malware-triage` | 278 | 8.2 | Perform static analysis and triage of suspicious files. Extract hashes, strings, metadata, PE headers, ELF inf |
| `memory-forensics` | 180 | 5.7 | Analyze memory dumps using Volatility 3 and strings. Enumerate processes, network connections, injected code,  |
| `network-forensics` | 219 | 7.4 | Analyze PCAP/PCAPNG network captures using tshark. Detect C2 beacons, data exfiltration, lateral movement, DNS |
| `reverse-engineering` | 346 | 9.0 | Reverse engineer binaries using radare2 (r2), rabin2, objdump, readelf, and strings. Analyze PE/ELF executable |
| `timeline` | 202 | 6.1 | Build a unified forensic timeline from multiple evidence sources — filesystem MACBtimes, logs, memory artifact |
| `tools` | 130 | 6.3 | List all available DFIR/SOC skills and installed forensic tools with descriptions and use cases. Quick referen |
