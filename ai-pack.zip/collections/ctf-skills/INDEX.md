# ctf-skills

来源仓库：`ljagiello__ctf-skills`，共 12 个 skill。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `ctf-ai-ml` | 119 | 6.9 | Provides AI and machine learning techniques for CTF challenges. Use when attacking ML models, crafting adversa |
| `ctf-crypto` | 334 | 41.1 | Provides cryptography attack techniques for CTF challenges. Use when attacking encryption, hashing, signatures |
| `ctf-forensics` | 381 | 36.2 | Provides digital forensics and signal analysis techniques for CTF challenges. Use when analyzing disk images,  |
| `ctf-malware` | 184 | 8.9 | Provides malware analysis and network traffic techniques for CTF challenges. Use when analyzing obfuscated scr |
| `ctf-misc` | 515 | 27.8 | Provides miscellaneous CTF challenge techniques for problems that do not cleanly fit the main categories. Use  |
| `ctf-osint` | 200 | 10.0 | Provides open source intelligence techniques for CTF challenges. Use when gathering information from public so |
| `ctf-pwn` | 229 | 20.4 | Provides binary exploitation techniques for CTF challenges. Use when you already have a vulnerable native targ |
| `ctf-reverse` | 198 | 15.6 | Provides reverse engineering techniques for CTF challenges. Use when the main job is to understand how a compi |
| `ctf-similar-search` | 176 | 6.3 | Searches for similar CTF challenge writeups using Tavily API for search and content extraction. Use when the u |
| `ctf-web` | 246 | 16.8 | Provides web exploitation techniques for CTF challenges. Use when the target is primarily an HTTP application, |
| `ctf-writeup` | 141 | 4.7 | Generates a single standardized submission-style CTF writeup for competition handoff and organizer review. Use |
| `solve-challenge` | 231 | 10.7 | Solves CTF challenges by performing first-pass triage, identifying the dominant category, and routing executio |
