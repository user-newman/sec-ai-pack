# Claude-Red

来源仓库：`SnailSploit__Claude-Red`，共 77 个 skill。

本集合过大，只保留索引；需要时按名称回原仓库取。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `offensive-active-directory` | 429 | 13.5 | Active Directory attack methodology for internal network red team engagements. Covers reconnaissance (BloodHou |
| `offensive-advanced-redteam` | 641 | 26.9 | Comprehensive red team operations methodology covering full engagement lifecycle from planning through reporti |
| `offensive-ai-security` | 596 | 39.2 | AI/LLM security offensive checklist: prompt injection, jailbreaking, model extraction, training data poisoning |
| `offensive-anti-forensics` | 468 | 19.0 | Anti-forensics and evidence destruction techniques for red team operators conducting authorized engagements. C |
| `offensive-api-abuse` | 500 | 21.9 | Advanced API exploitation methodology focused on business logic abuse and sophisticated attack patterns that b |
| `offensive-api-security` | 505 | 19.4 | Comprehensive API security testing methodology covering REST, gRPC, and WebSocket attack surfaces. Addresses t |
| `offensive-basic-exploitation` | 10787 | 346.3 | Week 5 exploit development curriculum. Foundational exploitation techniques: controlling EIP/RIP, ROP chain co |
| `offensive-bluetooth-ble` | 195 | 6.5 | Bluetooth Low Energy (BLE) attack methodology — GATT enumeration, characteristic read/write without auth, pair |
| `offensive-bluetooth-classic` | 157 | 5.3 | Bluetooth Classic (BR/EDR) attack methodology — device discovery, service enumeration via SDP, LMP/L2CAP layer |
| `offensive-bug-identification` | 1260 | 54.9 | Systematic bug identification methodology: source code review patterns, black-box testing strategies, taint an |
| `offensive-business-logic` | 399 | 13.0 | Business logic vulnerability testing for web/mobile/API engagements. Covers workflow bypass, state machine vio |
| `offensive-c2-frameworks` | 597 | 21.8 | Command and Control framework deployment, configuration, and operational tradecraft for red team engagements.  |
| `offensive-cicd-pipeline` | 520 | 19.7 | Comprehensive CI/CD pipeline exploitation methodology covering GitHub Actions injection vectors (expression in |
| `offensive-cicd-secrets` | 580 | 24.5 | Comprehensive secrets extraction methodology targeting CI/CD environments across all major platforms. Covers e |
| `offensive-cloud` | 347 | 12.3 | Cloud security attack methodology covering AWS, Azure, and GCP. Includes credential harvesting (IMDS, ~/.aws,  |
| `offensive-container-escape` | 673 | 21.2 | Container escape and breakout techniques targeting Docker, containerd, and Podman runtimes. Covers privileged  |
| `offensive-crash-analysis` | 12470 | 400.0 | Week 4 exploit development curriculum. Crash triage and analysis methodology: WinDbg/GDB analysis, ASAN/MSAN o |
| `offensive-crypto-attacks` | 477 | 19.9 | Systematic methodology for identifying and exploiting cryptographic implementation weaknesses in real-world ap |
| `offensive-data-exfiltration` | 551 | 19.2 | Dense methodology covering DNS exfiltration (dnscat2, iodine, dns2tcp), HTTPS tunneling (domain fronting, CDN  |
| `offensive-deauth-disassoc` | 133 | 4.5 | Deauthentication and disassociation attacks against 802.11 networks — targeted single-client deauth for handsh |
| `offensive-dependency-confusion` | 603 | 23.2 | Deep-dive offensive methodology for dependency confusion and namespace attacks across all major package ecosys |
| `offensive-deserialization` | 610 | 22.7 | Insecure deserialization exploitation across Java, PHP, .NET, Python, Node.js, and Ruby. Covers gadget chain c |
| `offensive-edr-evasion` | 1810 | 82.7 | EDR evasion offensive checklist: hook unhooking (user/kernel), direct syscalls, PPID spoofing, process injecti |
| `offensive-evil-twin` | 221 | 7.9 | Evil Twin / KARMA / Mana access point methodology — rogue AP construction with hostapd-mana / wifiphisher / ai |
| `offensive-exploit-dev-course` | 432 | 19.9 | Full exploit development course roadmap and syllabus: weekly topics, recommended reading, lab setup, and learn |
| `offensive-exploit-development` | 703 | 33.4 | Exploit development operational guide: environment setup, debugging workflow, PoC development lifecycle, writi |
| `offensive-fast-checking` | 491 | 23.6 | Speed-optimized offensive checklist for rapid assessment: quick-win vulnerability patterns, fast recon shortcu |
| `offensive-file-upload` | 826 | 30.3 | File upload vulnerability checklist: MIME type bypass, extension bypass, magic byte manipulation, path travers |
| `offensive-fuzzing` | 339 | 11.6 | Practical offensive fuzzing methodology covering target identification, fuzzer selection (AFL++, libFuzzer, Ho |
| `offensive-fuzzing-course` | 2109 | 78.9 | Week 2 of the exploit development curriculum. Covers fuzzing methodology: target selection, corpus generation, |
| `offensive-graphql` | 568 | 21.6 | Offensive methodology for attacking GraphQL APIs during penetration tests and bug bounty engagements. Covers t |
| `offensive-idor` | 612 | 25.3 | IDOR (Insecure Direct Object Reference) testing checklist: object ID enumeration, horizontal/vertical privileg |
| `offensive-initial-access` | 1532 | 64.4 | Initial access techniques checklist: phishing (spear/smishing), credential stuffing, exposed service exploitat |
| `offensive-iot` | 436 | 13.9 | IoT and embedded device security testing methodology. Covers hardware reconnaissance (UART, JTAG, SWD, SPI fla |
| `offensive-jwt` | 281 | 11.1 | JWT attack methodology for penetration testers. Covers algorithm confusion (alg:none, RS256→HS256), weak HMAC  |
| `offensive-k8s-attacks` | 809 | 26.8 | Kubernetes cluster attack techniques covering the full attack lifecycle from initial foothold in a pod to clus |
| `offensive-keylogger-arch` | 201 | 11.6 | Low-level keylogger architecture design: kernel driver hooks (WH_KEYBOARD_LL, SetWindowsHookEx), ETW-based inp |
| `offensive-krack-fragattacks` | 115 | 4.4 | KRACK (CVE-2017-13077..082) and FragAttacks (CVE-2020-24586..588 + 26139-26147) — key reinstallation, fragment |
| `offensive-lateral-movement` | 451 | 15.9 | Comprehensive lateral movement tradecraft for authorized red team engagements covering credential-based moveme |
| `offensive-linux-privesc` | 585 | 18.6 | Comprehensive Linux privilege escalation methodology for offensive security engagements. Covers the full attac |
| `offensive-lorawan-sub-ghz` | 183 | 6.8 | LoRaWAN and sub-GHz (433 / 868 / 915 MHz) attack methodology — LoRaWAN ABP/OTAA join attack, network/session k |
| `offensive-mitigations` | 1355 | 57.7 | Security mitigation reference and bypass catalog: ASLR, DEP/NX, RELRO, stack canaries, CFI, sandboxing, seccom |
| `offensive-mobile` | 423 | 13.7 | Mobile (Android + iOS) application penetration testing methodology. Covers static analysis (apktool/jadx for A |
| `offensive-netexec` | 856 | 24.1 | Use this skill whenever the user asks about NetExec (nxc) — a network exploitation and post-exploitation tool  |
| `offensive-network-attacks` | 492 | 19.7 | Dense description covering ARP spoofing, LLMNR/NBT-NS/mDNS poisoning, DNS poisoning, MITM attacks, VLAN hoppin |
| `offensive-oauth` | 370 | 15.0 | OAuth 2.0 attack checklist: authorization code interception, redirect_uri bypass, CSRF on OAuth flow, state pa |
| `offensive-open-redirect` | 491 | 16.2 | Open redirect vulnerability checklist: parameter identification, bypass techniques (URL encoding, double slash |
| `offensive-osint` | 400 | 22.2 | Comprehensive OSINT methodology skill for offensive security, red team intelligence gathering, and bug bounty  |
| `offensive-osint-methodology` | 440 | 23.1 | Structured OSINT methodology framework: target definition, source selection, collection workflows, data correl |
| `offensive-parameter-pollution` | 599 | 16.7 | HTTP parameter pollution (HPP) checklist: duplicate parameter injection, backend vs frontend parsing differenc |
| `offensive-persistence` | 601 | 23.0 | Comprehensive persistence tradecraft for authorized red team engagements covering Windows and Linux mechanisms |
| `offensive-phishing` | 520 | 18.9 | Phishing campaign execution methodology for authorized red team engagements. Covers end-to-end campaign lifecy |
| `offensive-race-condition` | 885 | 29.0 | Race condition (TOCTOU) testing checklist: identifying timing windows, Burp Suite Turbo Intruder, Last-Byte sy |
| `offensive-reporting` | 372 | 14.4 | Penetration test and red team report writing methodology. Covers executive summary structuring (risk-led narra |
| `offensive-request-smuggling` | 777 | 21.6 | HTTP request smuggling checklist: CL.TE, TE.CL, TE.TE variants, detection with timing and differential respons |
| `offensive-shellcode` | 476 | 18.4 | Shellcode development reference for offensive security engagements. Use when writing custom x86/x64 shellcode, |
| `offensive-social-engineering` | 577 | 22.4 | Social engineering attack techniques beyond email phishing for authorized red team and physical penetration te |
| `offensive-ssrf` | 834 | 25.6 | Server-Side Request Forgery testing checklist: SSRF discovery, blind SSRF with out-of-band, cloud metadata end |
| `offensive-ssti` | 628 | 23.2 | Dense description covering Server-Side Template Injection across Jinja2, Twig, Freemarker, Velocity, Pebble, S |
| `offensive-supply-chain` | 547 | 18.1 | Comprehensive offensive methodology for software supply chain attacks covering the full kill chain from reconn |
| `offensive-tls-attacks` | 536 | 25.0 | Comprehensive methodology for auditing and exploiting TLS/SSL implementations and misconfigurations across net |
| `offensive-toctou` | 348 | 12.6 | Time-of-Check / Time-of-Use (TOCTOU) race condition exploitation methodology across binary, kernel, filesystem |
| `offensive-vuln-classes` | 1233 | 94.5 | Exploit development curriculum covering core vulnerability classes with real-world CVE case studies: stack/hea |
| `offensive-waf-bypass` | 827 | 38.0 | WAF bypass techniques checklist: encoding bypass (URL/HTML/Unicode/double encoding), case variation, comment i |
| `offensive-wifi` | 346 | 10.8 | Wireless / 802.11 attack methodology for red team engagements and wireless security assessments. Covers monito |
| `offensive-wifi-recon` | 204 | 6.7 | Wi-Fi reconnaissance methodology — adapter selection, monitor mode and packet injection setup, regulatory doma |
| `offensive-windows-boundaries` | 15157 | 554.5 | Windows security boundary taxonomy and attack surface enumeration: kernel/user boundary, sandbox boundaries (L |
| `offensive-windows-mitigations` | 14550 | 518.4 | Deep-dive on Windows exploit mitigations: ASLR, DEP/NX, CFG, CET/Shadow Stack, SEHOP, Heap Guard, ACG, Arbitra |
| `offensive-windows-privesc` | 581 | 22.1 | Comprehensive Windows privilege escalation methodology for offensive security engagements. Covers the full att |
| `offensive-wpa-enterprise` | 208 | 7.5 | WPA/WPA2/WPA3-Enterprise (802.1X / EAP) attack methodology — EAP method identification (PEAP-MSCHAPv2, EAP-TTL |
| `offensive-wpa2-psk` | 177 | 6.1 | WPA/WPA2-PSK attack methodology — four-way handshake capture via targeted deauthentication, PMKID attacks (no  |
| `offensive-wpa3-sae` | 160 | 6.3 | WPA3 / SAE (Simultaneous Authentication of Equals) attack methodology — transition-mode (mixed WPA2/WPA3) down |
| `offensive-wps` | 167 | 5.7 | WPS (Wi-Fi Protected Setup) PIN attack methodology — Pixie Dust offline attack against vulnerable chipsets (Ra |
| `offensive-xss` | 788 | 24.6 | Cross-Site Scripting testing checklist: stored/reflected/DOM/blind XSS discovery, polyglot payloads, CSP bypas |
| `offensive-xxe` | 1000 | 28.1 | XML External Entity injection testing checklist: classic XXE, blind XXE (out-of-band), XXE via file upload (SV |
| `offensive-z-wave` | 147 | 5.3 | Z-Wave attack methodology — sniffing with Z-Force / EZ-Wave / RTL-SDR + ZniffMobile, S0 (legacy) network-key d |
| `offensive-zigbee-thread-matter` | 169 | 6.3 | Zigbee, Thread, and Matter mesh-protocol attack methodology — IEEE 802.15.4 sniffing with TI CC2531 / CC2540 / |
