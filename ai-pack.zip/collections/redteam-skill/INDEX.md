# redteam-skill

来源仓库：`pale-knight__redteam-skill`，共 18 个 skill。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `ad-attack` | 152 | 6.3 | Active Directory exploitation after domain credentials exist: Kerberos (AS-REP/Kerberoast including cracking t |
| `ad-recon` | 123 | 4.8 | Active Directory reconnaissance with or without credentials: user/group/computer enumeration, ACL/delegation,  |
| `cicd` | 323 | 11.3 | CI/CD pipeline and software-supply-chain exploitation: Jenkins, GitHub Actions, GitLab CI/CD, Azure DevOps, Gi |
| `cloud-attack` | 86 | 3.8 | Cloud control-plane exploitation for AWS, Azure/Entra, GCP, and Alibaba Cloud: IAM/RAM privilege escalation, i |
| `cloud-recon` | 109 | 4.1 | Cloud control-plane reconnaissance for AWS, Azure/Entra, GCP, and Alibaba Cloud: identity, IAM/RAM, trust, res |
| `creds` | 256 | 9.6 | Credential operations: secret discovery, classification, extraction, conversion, offline cracking of hashes th |
| `edr-bypass` | 337 | 10.7 | Endpoint defense evasion after an operator-selected chain already has a valid execution path but AV/EDR/AMSI/W |
| `k8s` | 134 | 5.1 | Kubernetes and container exploitation: identity/RBAC, secrets, kubelet/etcd, managed-cloud workload identities |
| `phishing` | 208 | 7.1 | Client-side initial access and social-engineering attack module. Use when the operator selects a human/client/ |
| `post` | 188 | 6.4 | OS post-exploitation after a stable host foothold: quiet host recon, host-native persistence (Windows Run/task |
| `privesc-linux` | 293 | 9.4 | Linux local privilege escalation from a low-privilege shell to root. Covers quiet vs loud enumeration, sudo/GT |
| `privesc-win` | 320 | 10.6 | Windows local privilege escalation from a low-privilege shell to Administrator or SYSTEM. Covers quiet vs loud |
| `recon` | 285 | 7.2 | 通用网络与资产信息收集。面向 IP、CIDR、主机名、企业/域名等尚未明确攻击面的目标，完成资产扩展、主机发现、TCP/UDP端口发现、服务/版本/协议识别、只读服务枚举、网络设备识别和漏洞候选研判。Recon only |
| `service-attack` | 237 | 7.3 | 直连网络服务攻击链。用于已经识别/枚举的非专门领域服务，从数据库、数据存储、文件/远程访问、基础设施、消息队列、DNS/网络服务、打印机/MFP/NAS/BMC/网络设备等服务入口继续利用到凭据、代码执行、主机控制、横向 |
| `shell` | 154 | 4.2 | Shell and session operations after an attack module already established command execution, a raw shell, webshe |
| `tunnel` | 175 | 4.5 | Network reachability and pivoting after an operator already has a foothold. Use to make previously unreachable |
| `web-attack` | 162 | 5.3 | HTTP/Web exploitation until a server shell or equivalent OS execution. Use after /web-recon has mapped the app |
| `web-recon` | 131 | 4.3 | HTTP/HTTPS application-layer reconnaissance after a web service is identified: fingerprinting, content/API dis |
