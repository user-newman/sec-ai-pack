# Anthropic-818

来源仓库：`mukul975__Anthropic-Cybersecurity-Skills`，共 818 个 skill。

本集合过大，只保留索引；需要时按名称回原仓库取。

| skill | 行数 | KB | 描述 |
|---|---|---|---|
| `abusing-dpapi-for-credential-access` | 210 | 10.4 | Extract and decrypt Windows DPAPI-protected secrets (Credential Manager, browser logins/cookies, Wi-Fi credent |
| `abusing-shadow-credentials-for-privesc` | 186 | 9.3 | Take over Active Directory accounts by writing attacker-controlled public keys to msDS-KeyCredentialLink (Shad |
| `achieving-cmmc-level-2-compliance` | 143 | 8.5 | Prepare a defense-contractor environment for CMMC Level 2 certification: scope CUI and FCI, implement the 110  |
| `acquiring-disk-image-with-dd-and-dcfldd` | 246 | 8.6 | Create forensically sound bit-for-bit disk images with dd or dcfldd on a Linux forensic workstation, preservin |
| `analyzing-active-directory-acl-abuse` | 91 | 4.1 | Detect dangerous ACL misconfigurations in Active Directory using ldap3 to identify GenericAll, WriteDACL, and  |
| `analyzing-android-malware-with-apktool` | 67 | 2.4 | Perform static analysis of Android APK malware using apktool for resource decompilation, jadx for Java source  |
| `analyzing-api-gateway-access-logs` | 82 | 2.3 | Parses API Gateway access logs (AWS API Gateway, Kong, Nginx) to detect BOLA/IDOR attacks, rate limit bypass,  |
| `analyzing-apt-group-with-mitre-navigator` | 291 | 11.2 | Query ATT&CK data with attackcti, mitreattack-python, and stix2, then build MITRE ATT&CK Navigator layers and  |
| `analyzing-azure-activity-logs-for-threats` | 88 | 2.4 | Queries Azure Monitor activity logs and sign-in logs via azure-monitor-query to detect suspicious administrati |
| `analyzing-bootkit-and-rootkit-samples` | 362 | 12.7 | Analyzes bootkit and advanced rootkit malware infecting the Master Boot Record (MBR), Volume Boot Record (VBR) |
| `analyzing-browser-forensics-with-hindsight` | 300 | 10.8 | Parse Chromium-based browser databases with Hindsight to extract and correlate browsing history, downloads, co |
| `analyzing-campaign-attribution-evidence` | 242 | 9.0 | Systematically evaluate cyber-campaign evidence to attribute an operation to a threat actor, using the Diamond |
| `analyzing-certificate-transparency-for-phishing` | 371 | 13.8 | Monitor Certificate Transparency logs using crt.sh and Certstream to detect phishing domains, lookalike certif |
| `analyzing-cloud-storage-access-patterns` | 78 | 2.3 | Detect abnormal access in AWS S3, GCS, and Azure Blob Storage by analyzing CloudTrail Data Events, GCS audit l |
| `analyzing-cobalt-strike-beacon-configuration` | 389 | 12.8 | Extract and analyze Cobalt Strike beacon configuration from PE files and memory dumps to identify C2 infrastru |
| `analyzing-cobaltstrike-malleable-c2-profiles` | 67 | 3.2 | Parse and analyze Cobalt Strike Malleable C2 profiles with dissect.cobaltstrike (profiles and beacon-payload c |
| `analyzing-command-and-control-communication` | 406 | 14.1 | Analyzes malware C2 communication over HTTP, HTTPS, DNS, and custom protocols to reverse-engineer beacon patte |
| `analyzing-cyber-kill-chain` | 149 | 7.1 | Analyzes intrusion activity against the Lockheed Martin Cyber Kill Chain framework to identify which phases an |
| `analyzing-disk-image-with-autopsy` | 268 | 10.5 | Perform comprehensive forensic analysis of raw (dd), E01, or AFF disk images with Autopsy and The Sleuth Kit,  |
| `analyzing-dns-logs-for-exfiltration` | 310 | 11.3 | Analyzes DNS query logs to detect data exfiltration via DNS tunneling, DGA domain communication, and covert C2 |
| `analyzing-docker-container-forensics` | 346 | 12.6 | Investigate compromised Docker containers by analyzing images, layers, volumes, logs, and runtime artifacts to |
| `analyzing-email-headers-for-phishing-investigation` | 366 | 12.4 | Parse and analyze email headers (Received chain, Return-Path, Message-ID) to trace the true origin of a phishi |
| `analyzing-ethereum-smart-contract-vulnerabilities` | 72 | 2.9 | Perform static and symbolic analysis of Solidity smart contracts using Slither and Mythril to detect reentranc |
| `analyzing-golang-malware-with-ghidra` | 321 | 11.1 | Reverse engineer Go-compiled malware in Ghidra by parsing Go buildinfo and pclntab structures, recovering stri |
| `analyzing-heap-spray-exploitation` | 65 | 2.3 | Detect and analyze heap spray attacks in memory dumps using Volatility3 plugins to identify NOP sled patterns, |
| `analyzing-indicators-of-compromise` | 194 | 7.6 | Analyzes indicators of compromise (IOCs) including IP addresses, domains, file hashes, URLs, and email artifac |
| `analyzing-ios-app-security-with-objection` | 207 | 6.4 | Runtime iOS app security testing with Objection (Frida): inspect keychain and filesystem data, explore app int |
| `analyzing-kubernetes-audit-logs` | 87 | 2.6 | Parses Kubernetes API server audit logs (JSON lines) to detect exec-into-pod, secret access, RBAC modification |
| `analyzing-linux-audit-logs-for-intrusion` | 276 | 9.6 | Uses the Linux Audit framework (auditd) with ausearch and aureport utilities to detect intrusion attempts, una |
| `analyzing-linux-elf-malware` | 371 | 12.2 | Analyze malicious Linux ELF binaries — botnets, cryptominers, ransomware, and rootkits targeting Linux servers |
| `analyzing-linux-kernel-rootkits` | 140 | 5.8 | Detect kernel-level rootkits in Linux memory dumps using Volatility3 linux plugins (check_syscall, lsmod, hidd |
| `analyzing-linux-system-artifacts` | 340 | 14.6 | Examine Linux system artifacts (auth logs, cron/systemd persistence, shell history, SSH keys, and system confi |
| `analyzing-lnk-file-and-jump-list-artifacts` | 294 | 11.0 | Analyze Windows LNK shortcut files and Jump List artifacts with LECmd, JLECmd, and manual Shell Link Binary Fo |
| `analyzing-macro-malware-in-office-documents` | 346 | 11.9 | Analyzes malicious VBA macros embedded in Microsoft Office documents (Word, Excel, PowerPoint) to identify dow |
| `analyzing-malicious-pdf-with-peepdf` | 97 | 3.1 | Perform static analysis of malicious PDF documents using peepdf, pdfid, and pdf-parser to extract embedded Jav |
| `analyzing-malicious-url-with-urlscan` | 113 | 4.0 | URLScan.io is a free service for scanning and analyzing suspicious URLs. It captures screenshots, DOM content, |
| `analyzing-malware-behavior-with-cuckoo-sandbox` | 305 | 11.4 | Detonate malware samples in Cuckoo Sandbox to observe runtime behavior — process creation, file system and reg |
| `analyzing-malware-family-relationships-with-malpedia` | 289 | 11.6 | Query the Malpedia API to look up malware family aliases and naming (platform.family_name), pull community/ven |
| `analyzing-malware-persistence-with-autoruns` | 130 | 4.6 | Use Sysinternals Autoruns to systematically enumerate and analyze malware persistence mechanisms across Window |
| `analyzing-malware-sandbox-evasion-techniques` | 72 | 2.8 | Detect sandbox and VM evasion techniques in malware samples by analyzing timing checks, VM/hypervisor artifact |
| `analyzing-memory-dumps-with-volatility` | 314 | 11.5 | Analyzes RAM memory dumps from compromised systems using the Volatility framework to identify malicious proces |
| `analyzing-memory-forensics-with-lime-and-volatility` | 92 | 2.5 | Performs Linux memory acquisition using LiME (Linux Memory Extractor) kernel module and analysis with Volatili |
| `analyzing-mft-for-deleted-file-recovery` | 262 | 10.4 | Analyze the NTFS Master File Table ($MFT) with MFTECmd, analyzeMFT, and X-Ways Forensics to recover metadata a |
| `analyzing-network-covert-channels-in-malware` | 221 | 7.8 | Detect and analyze covert communication channels used by malware, including DNS tunneling, ICMP exfiltration,  |
| `analyzing-network-flow-data-with-netflow` | 73 | 2.1 | Parse NetFlow v9 and IPFIX records to detect volumetric anomalies, port scanning, data exfiltration, and C2 be |
| `analyzing-network-packets-with-scapy` | 62 | 2.4 | Use Scapy to craft, send, sniff, and dissect TCP/UDP/ICMP/DNS packets, analyze pcap files, implement SYN scans |
| `analyzing-network-traffic-for-incidents` | 267 | 10.4 | Analyzes network traffic captures and flow data to identify adversary activity during security incidents, incl |
| `analyzing-network-traffic-of-malware` | 341 | 11.6 | Analyzes network traffic generated by malware during sandbox execution or live incident response to identify C |
| `analyzing-network-traffic-with-wireshark` | 235 | 10.1 | Captures and analyzes network packet data using Wireshark and tshark to identify malicious traffic patterns, d |
| `analyzing-office365-audit-logs-for-compromise` | 66 | 2.3 | Parse Office 365 Unified Audit Logs via Microsoft Graph API to detect email forwarding rule creation, inbox de |
| `analyzing-outlook-pst-for-email-forensics` | 355 | 12.5 | Parse Microsoft Outlook PST and OST files using libpff and pst-utils to extract message content, headers, atta |
| `analyzing-packed-malware-with-upx-unpacker` | 312 | 11.6 | Identifies and unpacks UPX-packed malware samples, including binaries with modified UPX magic bytes or headers |
| `analyzing-pdf-malware-with-pdfid` | 358 | 12.5 | Analyzes malicious PDF files using PDFiD, pdf-parser, and peepdf to identify embedded JavaScript, shellcode, e |
| `analyzing-persistence-mechanisms-in-linux` | 73 | 3.1 | Scan Linux systems for persistence mechanisms including crontab/systemd entries, LD_PRELOAD injection, shell p |
| `analyzing-powershell-empire-artifacts` | 73 | 2.8 | Detect PowerShell Empire post-exploitation framework artifacts in Windows Script Block Logging (Event ID 4104) |
| `analyzing-powershell-script-block-logging` | 78 | 2.6 | Parse Windows PowerShell Script Block Logs (Event ID 4104) from EVTX files to detect obfuscated commands, enco |
| `analyzing-prefetch-files-for-execution-history` | 327 | 11.9 | Parse Windows Prefetch files (versions 17, 23, 26, 30) with tools like PECmd, WinPrefetchView, or python-prefe |
| `analyzing-ransomware-encryption-mechanisms` | 362 | 13.9 | Analyzes encryption algorithms, key management, and file encryption routines used by ransomware families to as |
| `analyzing-ransomware-leak-site-intelligence` | 365 | 13.9 | Safely monitor ransomware group Tor-hosted data leak sites (DLS) to collect and extract structured victim post |
| `analyzing-ransomware-network-indicators` | 91 | 3.1 | Identify ransomware-related network indicators, including C2 beaconing patterns, TOR exit node connections, da |
| `analyzing-ransomware-payment-wallets` | 200 | 7.6 | Traces ransomware cryptocurrency payment flows using blockchain analysis tools such as Chainalysis Reactor, Wa |
| `analyzing-sbom-for-supply-chain-vulnerabilities` | 310 | 11.4 | Parses Software Bill of Materials (SBOM) in CycloneDX and SPDX JSON formats to identify supply chain vulnerabi |
| `analyzing-security-logs-with-splunk` | 272 | 9.8 | Leverages Splunk Enterprise Security and SPL (Search Processing Language) to investigate security incidents th |
| `analyzing-slack-space-and-file-system-artifacts` | 400 | 14.5 | Examine NTFS slack space, MFT entries, the USN Change Journal, and Alternate Data Streams (ADS) to recover hid |
| `analyzing-supply-chain-malware-artifacts` | 174 | 6.1 | Investigate supply chain attack artifacts including trojanized software updates, compromised build pipelines,  |
| `analyzing-threat-actor-ttps-with-mitre-attack` | 288 | 9.8 | Systematically map threat actor behavior and observed IOCs to the MITRE ATT&CK framework, build technique cove |
| `analyzing-threat-actor-ttps-with-mitre-navigator` | 88 | 2.6 | Map advanced persistent threat (APT) group TTPs to the MITRE ATT&CK framework using the attackcti Python libra |
| `analyzing-threat-intelligence-feeds` | 127 | 6.1 | Analyzes structured and unstructured threat intelligence feeds to extract actionable indicators, adversary tac |
| `analyzing-threat-landscape-with-misp` | 83 | 2.3 | Query a MISP (Malware Information Sharing Platform) instance via PyMISP to compute event statistics, IOC type  |
| `analyzing-tls-certificate-transparency-logs` | 114 | 2.9 | Queries Certificate Transparency logs via crt.sh and pycrtsh to detect phishing domains, unauthorized certific |
| `analyzing-typosquatting-domains-with-dnstwist` | 358 | 12.7 | Generate domain permutations with dnstwist and check DNS resolution to detect typosquatting, homograph phishin |
| `analyzing-uefi-bootkit-persistence` | 370 | 14.4 | Analyzes UEFI bootkit persistence (SPI flash implants, ESP modifications, Secure Boot bypass, UEFI variable ma |
| `analyzing-usb-device-connection-history` | 372 | 13.2 | Correlate Windows registry keys (USBSTOR, MountedDevices), Event Logs, and setupapi.dev.log to reconstruct USB |
| `analyzing-web-server-logs-for-intrusion` | 80 | 2.5 | Parse Apache and Nginx access logs to detect SQL injection attempts, local file inclusion, directory traversal |
| `analyzing-windows-amcache-artifacts` | 254 | 10.9 | Parses the Windows Amcache.hve registry hive with Eric Zimmerman's AmcacheParser and Timeline Explorer to extr |
| `analyzing-windows-event-logs-in-splunk` | 307 | 11.1 | Analyzes Windows Security, System, and Sysmon event logs in Splunk to detect authentication attacks, privilege |
| `analyzing-windows-lnk-files-for-artifacts` | 330 | 12.5 | Parse Windows LNK shortcut files to extract target paths, MAC timestamps, volume serial numbers, and machine i |
| `analyzing-windows-prefetch-with-python` | 119 | 4.9 | Parse Windows Prefetch (.pf) files with the windowsprefetch Python library to reconstruct application executio |
| `analyzing-windows-registry-for-artifacts` | 302 | 11.5 | Extract and analyze Windows Registry hives with tools like RegRipper and Registry Explorer to uncover user act |
| `analyzing-windows-shellbag-artifacts` | 225 | 8.9 | Analyze Windows Shellbag (BagMRU) registry artifacts with SBECmd and Shellbags Explorer to reconstruct folder  |
| `assessing-vector-and-embedding-weaknesses` | 237 | 11.8 | Test RAG vector stores (Pinecone, Qdrant, Weaviate, Chroma, pgvector, FAISS) for embedding inversion, cross-te |
| `attacking-entra-id-with-roadtools` | 207 | 8.4 | Enumerate Microsoft Entra ID (Azure AD) tenants with ROADrecon and acquire, exchange, and abuse tokens (includ |
| `attacking-oauth-with-device-code-phishing` | 246 | 14.8 | Run OAuth 2.0 device-code and illicit-consent phishing attacks against Microsoft Entra ID, using TokenTactics- |
| `auditing-aws-s3-bucket-permissions` | 275 | 10.7 | Systematically audit AWS S3 bucket permissions to identify publicly accessible buckets, overly permissive ACLs |
| `auditing-azure-active-directory-configuration` | 276 | 11.7 | Auditing Microsoft Entra ID (Azure Active Directory) configuration to identify risky authentication policies,  |
| `auditing-cloud-with-cis-benchmarks` | 266 | 11.8 | Audit AWS, Azure, and GCP environments against the CIS Foundations Benchmarks by running automated scans with  |
| `auditing-entra-id-with-aadinternals` | 189 | 10.5 | Drive the AADInternals PowerShell toolkit to perform Microsoft Entra ID tenant reconnaissance, access-token ac |
| `auditing-foundry-smart-contract-security` | 171 | 7.4 | Pre-deployment security audit of Solidity smart contracts in a Foundry project. Combines static analysis (Slit |
| `auditing-gcp-iam-permissions` | 327 | 12.4 | Auditing Google Cloud Platform IAM permissions to identify overly permissive bindings, primitive role usage, s |
| `auditing-kubernetes-cluster-rbac` | 355 | 13.0 | Auditing Kubernetes cluster RBAC configurations to identify overly permissive roles, wildcard permissions, dan |
| `auditing-kubernetes-rbac-privilege-escalation` | 269 | 11.8 | Finds over-permissive RBAC roles and service-account token abuse paths in a Kubernetes cluster using kubectl a |
| `auditing-mcp-servers-for-tool-poisoning` | 219 | 10.5 | Audit MCP servers for tool poisoning, tool shadowing, rug pulls, SSRF, and unauthenticated exposure using Inva |
| `auditing-terraform-infrastructure-for-security` | 359 | 11.6 | Auditing Terraform infrastructure-as-code for security misconfigurations using Checkov, tfsec, Terrascan, and  |
| `auditing-tls-certificate-transparency-logs` | 204 | 15.4 | Monitors Certificate Transparency (CT) logs to detect unauthorized certificate issuance, discover subdomains v |
| `auditing-uefi-firmware-with-chipsec` | 210 | 9.2 | Use Intel CHIPSEC to assess platform firmware configuration, SPI flash write protection, BIOS lock, SMM/SMRR,  |
| `automating-ioc-enrichment` | 219 | 8.5 | Automates the enrichment of raw indicators of compromise with multi-source threat intelligence context using S |
| `benchmarking-kubernetes-with-kube-bench` | 228 | 9.1 | Installs and runs the kube-bench tool against a Kubernetes cluster as a Job, DaemonSet, or standalone binary,  |
| `building-adversary-infrastructure-tracking-system` | 346 | 14.5 | Build an automated adversary infrastructure tracking system in Python (dnspython, python-whois, shodan, networ |
| `building-attack-pattern-library-from-cti-reports` | 328 | 13.4 | Parse cyber threat intelligence reports (Mandiant, CrowdStrike, Talos, Microsoft) with stix2, mitreattack-pyth |
| `building-automated-malware-submission-pipeline` | 508 | 18.6 | Builds an automated malware submission and analysis pipeline that collects suspicious files from endpoints and |
| `building-c2-infrastructure-with-sliver-framework` | 213 | 8.0 | Deploy and harden a Sliver C2 team server (BishopFox's Go-based adversary emulation framework) with multi-prot |
| `building-c2-redirector-infrastructure` | 214 | 11.3 | Build dumb-pipe and traffic-filtering C2 redirectors with nginx (proxy_pass) and Apache (mod_rewrite), derivin |
| `building-cloud-siem-with-sentinel` | 319 | 12.8 | Deploy Microsoft Sentinel as a cloud-native SIEM/SOAR by configuring multi-cloud data connectors (AWS, Azure,  |
| `building-detection-rule-with-splunk-spl` | 262 | 10.4 | Build effective detection rules using Splunk Search Processing Language (SPL) correlation searches to identify |
| `building-detection-rules-with-sigma` | 339 | 10.4 | Builds vendor-agnostic detection rules using the Sigma rule format for threat detection across SIEM platforms  |
| `building-devsecops-pipeline-with-gitlab-ci` | 264 | 8.7 | Configure a GitLab CI/CD pipeline that embeds SAST (Semgrep, SpotBugs, Gosec, Bandit, NodeJsScan), DAST, conta |
| `building-identity-federation-with-saml-azure-ad` | 264 | 9.8 | Configure SAML 2.0 identity federation between on-premises Active Directory (via AD FS or a third-party IdP) a |
| `building-identity-governance-lifecycle-process` | 720 | 28.4 | Design identity governance and lifecycle (IGA) programs on platforms like SailPoint, Saviynt, or Entra ID Gove |
| `building-incident-response-dashboard` | 311 | 11.0 | Builds real-time incident response dashboards in Splunk, Elastic, or Grafana to provide SOC analysts and leade |
| `building-incident-response-playbook` | 268 | 10.1 | Designs and documents structured incident response playbooks with step-by-step procedures per incident type, d |
| `building-incident-timeline-with-timesketch` | 273 | 9.3 | Build collaborative forensic incident timelines using Timesketch to ingest, normalize, and analyze multi-sourc |
| `building-ioc-defanging-and-sharing-pipeline` | 381 | 14.2 | Build an automated pipeline that ingests raw IOCs (URLs, IPs, domains, emails), normalizes and deduplicates th |
| `building-ioc-enrichment-pipeline-with-opencti` | 277 | 9.7 | Build an automated IOC enrichment pipeline on OpenCTI (STIX 2.1 native threat intel platform) using its intern |
| `building-malware-incident-communication-template` | 348 | 9.9 | Build structured communication templates for malware incidents (ransomware, wiper, trojan, worm), covering int |
| `building-patch-tuesday-response-process` | 228 | 9.1 | Establish a repeatable operational process for triaging, testing, and deploying Microsoft Patch Tuesday securi |
| `building-phishing-reporting-button-workflow` | 129 | 5.1 | Implement a phishing report button (Microsoft 365 built-in Report button or third-party like KnowBe4/Cofense)  |
| `building-ransomware-playbook-with-cisa-framework` | 208 | 8.5 | Builds a structured ransomware incident response playbook aligned with the CISA StopRansomware Guide and NIST  |
| `building-red-team-c2-infrastructure-with-havoc` | 324 | 10.5 | Deploy and configure the Havoc C2 framework (teamserver, HTTPS/HTTP/SMB listeners, Nginx redirectors, and Demo |
| `building-role-mining-for-rbac-optimization` | 263 | 10.1 | Apply bottom-up and top-down role mining techniques, including clustering algorithms and formal concept analys |
| `building-soc-escalation-matrix` | 224 | 7.1 | Build a structured SOC escalation matrix defining severity tiers, response SLAs, tiered escalation paths, and  |
| `building-soc-metrics-and-kpi-tracking` | 314 | 11.4 | Builds SOC performance metrics and KPI tracking dashboards measuring Mean Time to Detect (MTTD), Mean Time to  |
| `building-soc-playbook-for-ransomware` | 310 | 11.6 | Builds a structured SOC incident response playbook for ransomware attacks covering detection, containment, era |
| `building-super-timelines-with-plaso` | 170 | 7.5 | Generate forensic super-timelines with Plaso's log2timeline.py, pinfo.py, psort.py, and psteal.py CLI tools (f |
| `building-threat-actor-profile-from-osint` | 381 | 14.8 | Build threat actor profiles by collecting OSINT from vendor reports, paste sites, dark web forums, social medi |
| `building-threat-feed-aggregation-with-misp` | 344 | 12.4 | Deploy MISP via Docker and configure feeds from sources like abuse.ch, AlienVault OTX, and CIRCL to aggregate, |
| `building-threat-hunt-hypothesis-framework` | 96 | 3.5 | Build a systematic threat-hunt workflow that turns threat intelligence and ATT&CK gap analysis into testable h |
| `building-threat-intelligence-enrichment-in-splunk` | 313 | 10.5 | Build automated IOC enrichment pipelines in Splunk Enterprise Security by ingesting threat feeds into KV Store |
| `building-threat-intelligence-feed-integration` | 343 | 11.2 | Builds automated threat intelligence feed integration pipelines connecting STIX/TAXII feeds, open-source threa |
| `building-threat-intelligence-platform` | 322 | 10.0 | Design and deploy a Threat Intelligence Platform (TIP) by integrating open-source CTI tools (MISP, OpenCTI, Th |
| `building-vulnerability-aging-and-sla-tracking` | 292 | 10.8 | Implement a vulnerability aging dashboard and SLA tracking system that measures time-to-remediation against se |
| `building-vulnerability-dashboard-with-defectdojo` | 252 | 7.7 | Deploy DefectDojo as a centralized vulnerability management dashboard that ingests findings from 200+ security |
| `building-vulnerability-exception-tracking-system` | 184 | 6.8 | Build a vulnerability exception and risk acceptance tracking system covering approval workflows, compensating  |
| `building-vulnerability-scanning-workflow` | 353 | 12.5 | Builds a structured vulnerability scanning workflow using tools like Nessus, Qualys, and OpenVAS to discover,  |
| `bypassing-authentication-with-forced-browsing` | 285 | 10.7 | Discovering and accessing unprotected pages, APIs, and administrative interfaces by enumerating URLs and bypas |
| `coercing-authentication-with-coercer-petitpotam` | 176 | 8.7 | Trigger machine account authentication with PetitPotam (MS-EFSR) and Coercer (MS-RPRN, MS-DFSNM, MS-FSRVP, MS- |
| `collecting-indicators-of-compromise` | 273 | 10.5 | Systematically collects, categorizes, and distributes indicators of compromise (IOCs) during and after securit |
| `collecting-open-source-intelligence` | 152 | 6.9 | Collects and synthesizes open-source intelligence (OSINT) about threat actors, malicious infrastructure, and a |
| `collecting-threat-intelligence-with-misp` | 192 | 6.1 | Deploy MISP, configure threat feeds (MISP community, freetext, TAXII, CSV), and use the PyMISP API to programm |
| `collecting-volatile-evidence-from-compromised-host` | 252 | 9.6 | Collect volatile forensic evidence from a compromised host by following the order of volatility, preserving me |
| `conducting-api-security-testing` | 196 | 11.6 | Conducts security testing of REST, GraphQL, and gRPC APIs to identify vulnerabilities in authentication, autho |
| `conducting-cloud-incident-response` | 290 | 11.6 | Respond to security incidents in AWS, Azure, and GCP via identity-based containment, cloud-native log analysis |
| `conducting-cloud-penetration-testing` | 303 | 12.7 | This skill outlines methodologies for performing authorized penetration testing against AWS, Azure, and GCP cl |
| `conducting-cyber-risk-assessment-with-nist-800-30` | 146 | 9.8 | Conduct a defensible cybersecurity risk assessment using the NIST SP 800-30 Rev 1 methodology: prepare scope a |
| `conducting-domain-persistence-with-dcsync` | 210 | 8.4 | Perform DCSync attacks by abusing MS-DRSR replication rights (DS-Replication-Get-Changes/-All) to impersonate  |
| `conducting-external-reconnaissance-with-osint` | 184 | 12.1 | Conduct external recon using OSINT techniques to map an organization's external attack surface without touchin |
| `conducting-full-scope-red-team-engagement` | 203 | 7.7 | Plan and execute a comprehensive, MITRE ATT&CK-aligned red team engagement spanning threat modeling, reconnais |
| `conducting-gdpr-compliance-assessment` | 295 | 13.4 | Conduct comprehensive GDPR compliance assessments by evaluating data processing activities against EU Regulati |
| `conducting-internal-network-penetration-test` | 315 | 10.2 | Execute an internal network penetration test simulating an insider threat or post-breach attacker to identify  |
| `conducting-internal-reconnaissance-with-bloodhound-ce` | 199 | 8.0 | Conduct internal Active Directory reconnaissance using BloodHound Community Edition's graph database with the  |
| `conducting-malware-incident-response` | 223 | 9.8 | Respond to malware infections across enterprise endpoints by identifying the malware family, determining infec |
| `conducting-man-in-the-middle-attack-simulation` | 296 | 11.5 | Simulates man-in-the-middle attacks using Ettercap, mitmproxy, and Bettercap in authorized environments to int |
| `conducting-memory-forensics-with-volatility` | 288 | 10.4 | Performs memory forensics analysis using Volatility 3 to extract evidence of malware execution, process inject |
| `conducting-mobile-app-penetration-test` | 227 | 12.4 | Conducts penetration testing of iOS and Android mobile applications following the OWASP Mobile Application Sec |
| `conducting-network-penetration-test` | 208 | 12.4 | Conducts comprehensive network penetration tests against authorized target environments by performing host dis |
| `conducting-pass-the-ticket-attack` | 106 | 4.0 | Perform Pass-the-Ticket (PtT) lateral movement by extracting Kerberos TGT/TGS tickets from LSASS memory on a c |
| `conducting-phishing-incident-response` | 283 | 11.6 | Respond to phishing incidents by analyzing reported emails, extracting indicators, sandboxing URLs/attachments |
| `conducting-post-incident-lessons-learned` | 192 | 6.5 | Facilitate structured post-incident reviews to identify root causes, document what worked and failed, and prod |
| `conducting-social-engineering-penetration-test` | 371 | 11.2 | Design and execute a social engineering penetration test combining OSINT-driven target profiling with phishing |
| `conducting-social-engineering-pretext-call` | 222 | 8.0 | Plan and execute authorized vishing (voice phishing) pretext calls to assess employee susceptibility to social |
| `conducting-spearphishing-simulation-campaign` | 174 | 6.5 | Run a targeted spearphishing simulation for initial access by developing OSINT-derived pretexts, building payl |
| `conducting-wireless-network-penetration-test` | 189 | 10.9 | Conducts authorized wireless network penetration tests to assess the security of WiFi infrastructure by testin |
| `configuring-active-directory-tiered-model` | 76 | 2.7 | Implement Microsoft's Enhanced Security Admin Environment (ESAE) tiered administration model for Active Direct |
| `configuring-aws-verified-access-for-ztna` | 465 | 14.7 | Configure AWS Verified Access to provide VPN-less zero trust network access to internal apps, combining identi |
| `configuring-certificate-authority-with-openssl` | 104 | 3.4 | Build a two-tier PKI Certificate Authority hierarchy (offline Root CA plus issuing Intermediate CA) using Open |
| `configuring-host-based-intrusion-detection` | 231 | 8.3 | Configures host-based intrusion detection systems (HIDS) to monitor endpoint file integrity, system calls, and |
| `configuring-hsm-for-key-storage` | 112 | 3.8 | Configures Hardware Security Modules for cryptographic key storage using the PKCS#11 standard interface, cover |
| `configuring-identity-aware-proxy-with-google-iap` | 414 | 14.4 | Configures Google Cloud Identity-Aware Proxy (IAP) via gcloud to enforce per-request identity verification on  |
| `configuring-ldap-security-hardening` | 96 | 3.0 | Hardens LDAP directory services against credential harvesting, LDAP injection, anonymous binding, and channel- |
| `configuring-microsegmentation-for-zero-trust` | 180 | 8.0 | Configures microsegmentation policies to enforce least-privilege workload-to-workload access using tools such  |
| `configuring-multi-factor-authentication-with-duo` | 158 | 6.3 | Deploys Cisco Duo multi-factor authentication across enterprise applications, VPN, RDP, and SSH access points, |
| `configuring-network-segmentation-with-vlans` | 429 | 13.3 | Designs and implements VLAN-based (802.1Q) network segmentation on managed switches to isolate zones such as c |
| `configuring-oauth2-authorization-flow` | 172 | 6.7 | Configures secure OAuth 2.0 authorization flows, including Authorization Code with PKCE, Client Credentials, a |
| `configuring-pfsense-firewall-rules` | 355 | 12.1 | Configures pfSense firewall rules, NAT policies, IPsec/OpenVPN tunnels, and traffic shaping to enforce network |
| `configuring-snort-ids-for-intrusion-detection` | 415 | 13.7 | Installs, configures, and tunes Snort 3 to monitor network traffic for malicious activity using custom and com |
| `configuring-suricata-for-network-monitoring` | 410 | 14.1 | Deploys and configures Suricata IDS/IPS with Emerging Threats rulesets, EVE JSON logging, and custom rules for |
| `configuring-tls-1-3-for-secure-communications` | 113 | 4.2 | Configures TLS 1.3 (RFC 8446) on servers, covering cipher suite and key-exchange group selection, and validate |
| `configuring-windows-defender-advanced-settings` | 293 | 12.0 | Configures Microsoft Defender for Endpoint (MDE) advanced protection settings including attack surface reducti |
| `configuring-windows-event-logging-for-detection` | 195 | 6.4 | Configures Windows Event Logging with advanced audit policies to generate high-fidelity security events for th |
| `configuring-zscaler-private-access-for-ztna` | 319 | 11.4 | Configures Zscaler Private Access (ZPA) to replace traditional VPN with zero trust network access by deploying |
| `containing-active-breach` | 232 | 10.4 | Executes containment strategies to stop active adversary operations and prevent lateral movement during a conf |
| `continuous-llm-red-teaming-with-promptfoo` | 210 | 9.6 | Wires Promptfoo and DeepTeam into CI/CD for automated, repeatable red-teaming of LLM apps against OWASP LLM To |
| `correlating-security-events-in-qradar` | 296 | 10.0 | Correlates security events in IBM QRadar SIEM using AQL (Ariel Query Language), custom rules, building blocks, |
| `correlating-threat-campaigns` | 169 | 7.1 | Correlates disparate security incidents, IOCs, and adversary behaviors across time and organizations to identi |
| `defending-llms-with-guardrails` | 285 | 12.1 | Deploys Llama Guard 3 safety classification, NeMo Guardrails programmable dialogue rails, and LLM Guard input/ |
| `deobfuscating-javascript-malware` | 361 | 12.8 | Deobfuscates malicious JavaScript found in phishing pages, web skimmers, and dropper scripts by reversing enco |
| `deobfuscating-powershell-obfuscated-malware` | 387 | 13.9 | Systematically deobfuscates multi-layer PowerShell malware using AST analysis, dynamic tracing, and tools like |
| `deploying-active-directory-honeytokens` | 261 | 9.4 | Deploys deception-based honeytokens in Active Directory including fake privileged accounts with AdminCount=1,  |
| `deploying-cloud-deception-with-decoy-resources` | 170 | 11.0 | Deploy cloud-native deception across AWS, Azure, and GCP using decoy (honey) resources whose only purpose is t |
| `deploying-cloudflare-access-for-zero-trust` | 400 | 14.9 | Deploys Cloudflare Access with Cloudflare Tunnel for zero trust access to self-hosted apps, configuring identi |
| `deploying-decoy-files-for-ransomware-detection` | 223 | 8.1 | Deploys canary files (honeytokens) across file systems to detect ransomware encryption activity in real time.  |
| `deploying-edr-agent-with-crowdstrike` | 276 | 9.6 | Deploys and configures CrowdStrike Falcon EDR agents across enterprise endpoints to enable real-time threat de |
| `deploying-honeytokens-and-canarytokens` | 233 | 12.7 | Plants Canarytokens-based decoy artifacts (honey credentials, DNS tokens, web-bug URLs, AWS keys, documents, k |
| `deploying-osquery-for-endpoint-monitoring` | 206 | 7.1 | Deploys and configures osquery for real-time endpoint monitoring using SQL-based queries to inspect running pr |
| `deploying-palo-alto-prisma-access-zero-trust` | 306 | 10.9 | Deploys Palo Alto Networks Prisma Access for SASE-based zero trust network access, configuring GlobalProtect a |
| `deploying-ransomware-canary-files` | 114 | 4.7 | Deploys and monitors ransomware canary files using Python's watchdog library, placing decoy files mimicking hi |
| `deploying-software-defined-perimeter` | 192 | 7.9 | Deploys a Software-Defined Perimeter per the CSA v2.0 specification, configuring Single Packet Authorization,  |
| `deploying-tailscale-for-zero-trust-vpn` | 437 | 11.2 | Deploys and configures Tailscale (or self-hosted Headscale) as a WireGuard-based zero trust mesh VPN, setting  |
| `designing-adversary-engagement-with-mitre-engage` | 164 | 11.6 | Plan, run, and measure an adversary engagement operation using the MITRE Engage framework so that deployed dec |
| `detecting-ai-model-prompt-injection-attacks` | 171 | 7.5 | Detects prompt injection using regex signature matching, heuristic scoring for structural anomalies, and DeBER |
| `detecting-anomalies-in-industrial-control-systems` | 333 | 12.5 | Deploys anomaly detection for OT/ICS environments using machine learning on OT network baselines, physics-base |
| `detecting-anomalous-authentication-patterns` | 758 | 29.4 | Detects anomalous authentication patterns using UEBA analytics, statistical baselines, and machine learning mo |
| `detecting-api-enumeration-attacks` | 432 | 14.3 | Detect API enumeration attacks (BOLA/IDOR, OWASP API1:2023) by writing SIEM detection rules that flag sequenti |
| `detecting-arp-poisoning-in-network-traffic` | 421 | 14.8 | Detect Layer 2 ARP poisoning/spoofing by deploying ARPWatch, Dynamic ARP Inspection (DAI), Wireshark packet an |
| `detecting-attacks-on-historian-servers` | 298 | 11.7 | Detect cyber attacks on OT historian servers (OSIsoft PI, Ignition, GE Proficy, Wonderware InSQL) using a Pyth |
| `detecting-attacks-on-scada-systems` | 723 | 26.9 | This skill covers detecting cyber attacks targeting Supervisory Control and Data Acquisition (SCADA) systems i |
| `detecting-aws-cloudtrail-anomalies` | 95 | 2.9 | Detect unusual API call patterns in AWS CloudTrail logs using boto3, statistical baselining, and behavioral an |
| `detecting-aws-credential-exposure-with-trufflehog` | 312 | 11.3 | Scan source code repositories, CI/CD pipelines, and configuration files for exposed AWS credentials using Truf |
| `detecting-aws-guardduty-findings-automation` | 349 | 10.4 | Build automated AWS GuardDuty finding response pipelines using EventBridge and Lambda to trigger real-time inc |
| `detecting-aws-iam-privilege-escalation` | 67 | 2.4 | Detect AWS IAM privilege escalation paths using boto3 and Cloudsplaining policy analysis to identify overly pe |
| `detecting-azure-lateral-movement` | 86 | 3.2 | Detect lateral movement in Azure AD/Entra ID environments using Microsoft Graph API audit logs, Azure Sentinel |
| `detecting-azure-service-principal-abuse` | 252 | 8.4 | Detect Azure service principal abuse in Microsoft Entra ID using KQL detection queries (Sentinel/Splunk) again |
| `detecting-azure-storage-account-misconfigurations` | 76 | 2.9 | Audit Azure Blob and ADLS storage accounts for public access exposure, weak or long-lived SAS tokens, missing  |
| `detecting-beaconing-patterns-with-zeek` | 90 | 2.6 | Performs statistical analysis of Zeek conn.log connection intervals to detect C2 beaconing patterns. Uses the  |
| `detecting-bluetooth-low-energy-attacks` | 316 | 13.3 | Detects and analyzes Bluetooth Low Energy (BLE) security attacks including sniffing, replay attacks, GATT enum |
| `detecting-broken-object-property-level-authorization` | 413 | 15.6 | Detect and test for OWASP API3:2023 Broken Object Property Level Authorization (BOPLA), covering excessive dat |
| `detecting-business-email-compromise` | 151 | 5.0 | Detect Business Email Compromise (BEC) fraud, where attackers impersonate executives or vendors to trick emplo |
| `detecting-business-email-compromise-with-ai` | 151 | 5.6 | Deploy AI and NLP-powered detection systems to identify business email compromise attacks by analyzing writing |
| `detecting-cloud-threats-with-guardduty` | 298 | 12.0 | Deploy and operationalize Amazon GuardDuty, covering protection plans for S3, EKS, EC2 runtime monitoring, and |
| `detecting-command-and-control-over-dns` | 1380 | 51.5 | Detect command-and-control (C2) traffic tunneled over DNS from tools like Iodine, dnscat2, dns2tcp, and Cobalt |
| `detecting-compromised-cloud-credentials` | 375 | 15.2 | Detect compromised cloud credentials across AWS, Azure, and GCP by analyzing anomalous API activity, impossibl |
| `detecting-container-drift-at-runtime` | 252 | 8.3 | Detects unauthorized runtime drift in containers by monitoring binary execution, filesystem changes, and confi |
| `detecting-container-escape-attempts` | 334 | 11.3 | Detects container escape at runtime across tooling - namespace manipulation, capability abuse, kernel exploits |
| `detecting-container-escape-with-falco-rules` | 350 | 10.5 | Writes and tunes Falco rule syntax for container escape detection - conditions, macros, lists, priorities, and |
| `detecting-container-runtime-threats-with-falco` | 293 | 11.6 | Deploys and operates Falco with the modern eBPF driver in Kubernetes and Docker, covering driver selection, He |
| `detecting-credential-dumping-techniques` | 97 | 3.3 | Detect LSASS credential dumping, SAM database extraction, and NTDS.dit theft (e.g. via Mimikatz) using Sysmon  |
| `detecting-cryptomining-in-cloud` | 363 | 14.2 | This skill teaches security teams how to detect and respond to unauthorized cryptocurrency mining operations i |
| `detecting-data-and-model-poisoning` | 216 | 10.7 | Identify poisoned training data and backdoored ML models across the pipeline using IBM's Adversarial Robustnes |
| `detecting-dcsync-attack-in-active-directory` | 160 | 6.6 | Detect DCSync attacks (MITRE T1003.006) where adversaries abuse Active Directory replication privileges to ext |
| `detecting-deepfake-audio-in-vishing-attacks` | 277 | 11.1 | Detect AI-generated deepfake audio used in voice phishing (vishing) by extracting spectral features (MFCC, spe |
| `detecting-dependency-confusion` | 225 | 11.5 | Detect and prevent dependency confusion (public-over-private package name resolution) in npm, PyPI, and Maven  |
| `detecting-dll-sideloading-attacks` | 109 | 4.4 | Detect DLL side-loading and search-order hijacking (MITRE T1574) where adversaries plant malicious DLLs for le |
| `detecting-dnp3-protocol-anomalies` | 366 | 13.9 | Detect anomalies in DNP3 communications used in SCADA/ICS systems by monitoring unauthorized control commands, |
| `detecting-dns-exfiltration-with-dns-query-analysis` | 450 | 16.4 | Detect data exfiltration via DNS tunneling (tools like iodine, dnscat2, dns2tcp) by analyzing query entropy, s |
| `detecting-email-account-compromise` | 66 | 3.2 | Detect compromised O365 and Google Workspace email accounts by analyzing Unified Audit Logs and Azure AD sign- |
| `detecting-email-forwarding-rules-attack` | 106 | 3.6 | Detect malicious inbox/mail-flow forwarding rules that adversaries create to maintain persistent access to ema |
| `detecting-entra-offensive-tools-in-graph-logs` | 195 | 10.9 | Hunt AADGraphActivityLogs and MicrosoftGraphActivityLogs in Microsoft Sentinel/Log Analytics using KQL to fing |
| `detecting-evasion-techniques-in-endpoint-logs` | 270 | 9.5 | Detects defense evasion techniques used by adversaries in endpoint logs including log tampering, timestomping, |
| `detecting-exfiltration-over-dns-with-zeek` | 95 | 4.0 | Detect DNS-based data exfiltration by analyzing Zeek dns.log for high-entropy subdomains, oversized TXT/NULL r |
| `detecting-fileless-attacks-on-endpoints` | 183 | 6.9 | Detects fileless malware and in-memory attacks that execute entirely in RAM without writing persistent files t |
| `detecting-fileless-malware-techniques` | 434 | 16.4 | Detects and analyzes fileless malware that operates entirely in memory using PowerShell, WMI, .NET reflection, |
| `detecting-golden-ticket-attacks-in-kerberos-logs` | 110 | 4.6 | Detect Golden Ticket attacks in Active Directory using Splunk and KQL queries against domain controller event  |
| `detecting-golden-ticket-forgery` | 73 | 2.6 | Detect Kerberos Golden Ticket forgery (e.g. Mimikatz-forged tickets) by analyzing Windows Event ID 4769 for RC |
| `detecting-indirect-prompt-injection` | 237 | 10.8 | Detect and defend against indirect prompt injection hidden in web pages, documents, and images consumed by an  |
| `detecting-insider-data-exfiltration-via-dlp` | 86 | 2.4 | Detects insider data exfiltration by analyzing DLP policy violations, file access patterns, upload volume anom |
| `detecting-insider-threat-behaviors` | 105 | 3.5 | Detect insider threat behavioral indicators including unusual data access, off-hours activity, mass file downl |
| `detecting-insider-threat-with-ueba` | 73 | 2.9 | Implement User and Entity Behavior Analytics (UEBA) using Elasticsearch/OpenSearch to build behavioral baselin |
| `detecting-kerberoasting-attacks` | 107 | 3.6 | Detect Kerberoasting attacks by monitoring for anomalous Kerberos TGS requests (Event ID 4769) targeting servi |
| `detecting-lateral-movement-in-network` | 453 | 16.6 | Identifies lateral movement techniques in enterprise networks by analyzing authentication logs, network flows, |
| `detecting-lateral-movement-with-splunk` | 118 | 4.5 | Detect adversary lateral movement across networks using Splunk SPL queries against Windows authentication logs |
| `detecting-lateral-movement-with-zeek` | 215 | 7.5 | Detect lateral movement in network traffic using Zeek (formerly Bro) log analysis. Parses conn.log, smb_mappin |
| `detecting-living-off-the-land-attacks` | 525 | 18.4 | Detect abuse of legitimate Windows binaries (LOLBins) used for living off the land attacks. Monitors process c |
| `detecting-living-off-the-land-with-lolbas` | 75 | 3.1 | Detect Living Off the Land Binaries (LOLBins/LOLBAS) abuse including certutil, regsvr32, mshta, and rundll32 v |
| `detecting-malicious-npm-packages` | 200 | 10.2 | Triage npm packages and lockfiles for install-script malware, credential exfiltration, and worming behavior us |
| `detecting-malicious-scheduled-tasks-with-sysmon` | 87 | 2.9 | Detect malicious scheduled task creation and modification using Sysmon Event IDs 1 (Process Create for schtask |
| `detecting-mimikatz-execution-patterns` | 104 | 3.5 | Detect Mimikatz credential-dumping activity via command-line pattern matching, LSASS access signatures, binary |
| `detecting-misconfigured-azure-storage` | 278 | 12.1 | Audit Azure Storage accounts for public blob containers, missing encryption, overly permissive SAS tokens, dis |
| `detecting-mobile-malware-behavior` | 243 | 8.6 | Detects and analyzes malicious behavior in mobile applications through behavioral analysis, permission abuse d |
| `detecting-modbus-command-injection-attacks` | 514 | 20.1 | Detect command injection against Modbus TCP/RTU in ICS/SCADA environments by monitoring unauthorized writes, a |
| `detecting-modbus-protocol-anomalies` | 398 | 14.6 | Detect anomalies in Modbus/TCP and Modbus RTU industrial traffic via function code monitoring, register range  |
| `detecting-model-extraction-attacks` | 205 | 11.5 | Detect MITRE ATLAS AML.T0024 attacks (model stealing, inversion, membership inference) performed via inference |
| `detecting-network-anomalies-with-zeek` | 407 | 14.1 | Deploy and configure Zeek (formerly Bro) to passively analyze network traffic, generate structured connection/ |
| `detecting-network-scanning-with-ids-signatures` | 311 | 13.6 | Detect network reconnaissance and port scanning using Suricata and Snort IDS signatures, threshold-based detec |
| `detecting-ntlm-relay-with-event-correlation` | 769 | 33.9 | Detect NTLM relay attacks (T1557.001) by correlating Windows Event 4624 LogonType 3 for IP-to-hostname mismatc |
| `detecting-oauth-token-theft` | 308 | 12.5 | Detect and respond to OAuth token theft and replay in Microsoft Entra ID (Azure AD), covering access token the |
| `detecting-pass-the-hash-attacks` | 102 | 3.5 | Detect Pass-the-Hash (T1550.002) attacks by analyzing NTLM authentication patterns, flagging Type 3 logons usi |
| `detecting-pass-the-ticket-attacks` | 70 | 2.8 | Detect Kerberos Pass-the-Ticket (PtT) attacks by analyzing Windows Event IDs 4768, 4769, and 4771 for anomalou |
| `detecting-port-scanning-with-fail2ban` | 378 | 12.7 | Configures Fail2ban with custom filters and actions to detect port scanning activity, SSH brute force attempts |
| `detecting-privilege-escalation-attempts` | 103 | 3.6 | Detect privilege escalation attempts across Windows and Linux, including access token manipulation, UAC bypass |
| `detecting-privilege-escalation-in-kubernetes-pods` | 270 | 9.2 | Detects and prevents privilege escalation inside Kubernetes pods by combining admission control (OPA policies) |
| `detecting-process-hollowing-technique` | 120 | 4.8 | Detect process hollowing (MITRE T1055.012) by analyzing memory-mapped sections, hollowed process indicators, a |
| `detecting-process-injection-techniques` | 372 | 13.9 | Detects and analyzes process injection techniques used by malware including classic DLL injection, process hol |
| `detecting-qr-code-phishing-with-email-security` | 159 | 6.6 | Detect and prevent QR code phishing (quishing) attacks that embed malicious URLs inside QR code images to bypa |
| `detecting-ransomware-encryption-behavior` | 239 | 8.6 | Detects ransomware encryption activity in real time using entropy analysis, file system I/O monitoring (Sysmon |
| `detecting-ransomware-precursors-in-network` | 328 | 14.5 | Detects early-stage ransomware indicators in network traffic before encryption begins, including initial acces |
| `detecting-rdp-brute-force-attacks` | 81 | 3.0 | Detect RDP brute force attacks by parsing Windows Security Event Logs (EVTX files, via python-evtx) for failed |
| `detecting-rootkit-activity` | 314 | 11.7 | Detects rootkit presence on compromised systems by identifying hidden processes, hooked system calls, modified |
| `detecting-s3-data-exfiltration-attempts` | 345 | 12.2 | Detecting data exfiltration attempts from AWS S3 buckets by analyzing CloudTrail S3 data events, VPC Flow Logs |
| `detecting-secure-boot-bypass` | 194 | 10.0 | Detect UEFI Secure Boot bypasses and bootkits such as BlackLotus and Bootkitty by verifying Secure Boot state, |
| `detecting-serverless-function-injection` | 506 | 24.6 | Detects and prevents code injection attacks targeting serverless functions (AWS Lambda, Azure Functions, Googl |
| `detecting-service-account-abuse` | 106 | 3.5 | Detect abuse of service accounts by hunting for anomalous interactive logons, privilege escalation, and latera |
| `detecting-shadow-api-endpoints` | 385 | 14.1 | Discover and inventory shadow API endpoints that operate outside documented OpenAPI/Swagger specs, using traff |
| `detecting-shadow-it-cloud-usage` | 69 | 2.5 | Detect unauthorized SaaS and cloud service usage (shadow IT) by parsing proxy access logs, DNS query logs, and |
| `detecting-spearphishing-with-email-gateway` | 153 | 5.4 | Detect and block spearphishing emails that use personalized, researched content to evade generic spam filters, |
| `detecting-sql-injection-via-waf-logs` | 73 | 2.2 | Analyze WAF (ModSecurity/AWS WAF/Cloudflare) logs to detect SQL injection attack campaigns. Parses ModSecurity |
| `detecting-stuxnet-style-attacks` | 495 | 19.1 | Detects sophisticated cyber-physical attacks that follow the Stuxnet pattern of modifying PLC logic while spoo |
| `detecting-supply-chain-attacks-in-ci-cd` | 91 | 2.6 | Scans GitHub Actions workflows and CI/CD pipeline configurations for supply chain attack vectors including unp |
| `detecting-suspicious-oauth-application-consent` | 66 | 2.4 | Detect risky OAuth application consent grants in Azure AD / Microsoft Entra ID using Microsoft Graph API, audi |
| `detecting-suspicious-powershell-execution` | 106 | 3.6 | Hunt for suspicious PowerShell execution (T1059.001) such as encoded commands, download cradles, AMSI bypass,  |
| `detecting-t1003-credential-dumping-with-edr` | 192 | 7.1 | Detect OS credential dumping (MITRE T1003) targeting LSASS memory, the SAM database, NTDS.dit, and cached cred |
| `detecting-t1055-process-injection-with-sysmon` | 181 | 7.7 | Detect process injection techniques (T1055) - including DLL injection, process hollowing, and APC injection -  |
| `detecting-t1548-abuse-elevation-control-mechanism` | 145 | 5.7 | Detect abuse of elevation control mechanisms (T1548), including Windows UAC bypass via auto-elevating binaries |
| `detecting-typosquatting-packages` | 231 | 11.7 | Flag misspelled, brandjacked, and typosquatted package names across npm, PyPI, and crates.io before installati |
| `detecting-typosquatting-packages-in-npm-pypi` | 177 | 13.0 | Detects typosquatting attacks in npm and PyPI package registries by analyzing package name similarity using Le |
| `detecting-wmi-persistence` | 102 | 3.6 | Detect WMI event subscription persistence (MITRE T1546.003) by analyzing Sysmon Event IDs 19, 20, and 21 for m |
| `emulating-cloud-attacks-with-stratus-red-team` | 225 | 11.1 | Install and run Stratus Red Team to detonate granular, MITRE ATT&CK-mapped AWS, Azure, GCP, and Kubernetes att |
| `enumerating-cloud-with-cloudfox` | 211 | 9.6 | Run CloudFox's read-only Describe/List/Get enumeration (all-checks, role-trusts, secrets, endpoints, and permi |
| `eradicating-malware-from-infected-systems` | 237 | 8.5 | Systematically map and remove malware, backdoors, and attacker persistence mechanisms (registry Run keys, sche |
| `escaping-containers-to-host` | 284 | 13.3 | Exploits privileged pods, host mounts, runC CVEs, and exposed Docker sockets to break out of a container and r |
| `evaluating-threat-intelligence-platforms` | 170 | 7.3 | Evaluates and selects Threat Intelligence Platform (TIP) products based on organizational requirements includi |
| `executing-active-directory-attack-simulation` | 198 | 13.4 | Executes authorized attack simulations against Active Directory environments to identify misconfigurations, we |
| `executing-nist-rmf-authorization-to-operate` | 143 | 8.6 | Drive a federal system through the NIST Risk Management Framework (SP 800-37 Rev 2) to an Authorization to Ope |
| `executing-phishing-simulation-campaign` | 234 | 12.5 | Executes authorized phishing simulation campaigns to assess an organization's susceptibility to email-based so |
| `executing-red-team-engagement-planning` | 160 | 6.8 | Build the foundational red team engagement plan - scope definition, Rules of Engagement (restrictions, communi |
| `executing-red-team-exercise` | 201 | 12.8 | Run a stealthy, MITRE ATT&CK-mapped adversary emulation against an organization's people, processes, and techn |
| `exploiting-active-directory-certificate-services-esc1` | 186 | 7.7 | Exploit misconfigured Active Directory Certificate Services (AD CS) ESC1 vulnerability to request certificates |
| `exploiting-active-directory-with-bloodhound` | 134 | 5.0 | BloodHound is a graph-based Active Directory reconnaissance tool that uses graph theory to reveal hidden and u |
| `exploiting-adcs-with-certipy` | 206 | 10.4 | Use Certipy to enumerate AD CS certificate authorities and templates over LDAP/RPC, then exploit ESC1-ESC16 mi |
| `exploiting-api-injection-vulnerabilities` | 480 | 19.4 | Tests API parameters, headers, and request bodies for injection flaws — SQL injection, NoSQL injection, OS com |
| `exploiting-aws-with-pacu` | 217 | 10.2 | Runs the Pacu AWS exploitation framework end-to-end — session and credential setup, IAM enumeration, automated |
| `exploiting-bgp-hijacking-vulnerabilities` | 358 | 12.3 | Analyzes and simulates BGP hijacking scenarios in authorized lab environments to assess route origin validatio |
| `exploiting-broken-function-level-authorization` | 380 | 15.8 | Tests APIs for Broken Function Level Authorization (OWASP API5:2023) by identifying admin and privileged endpo |
| `exploiting-broken-link-hijacking` | 240 | 9.1 | Discovers and exploits broken link hijacking by spidering a site (Burp Suite Spider, Scrapy, curl scraping), e |
| `exploiting-constrained-delegation-abuse` | 210 | 8.9 | Exploits Kerberos Constrained Delegation misconfigurations in Active Directory using Impacket's findDelegation |
| `exploiting-deeplink-vulnerabilities` | 191 | 6.7 | Tests and exploits deep link (URL scheme and App Link) vulnerabilities in Android and iOS mobile applications  |
| `exploiting-excessive-data-exposure-in-api` | 391 | 15.8 | Tests APIs for excessive data exposure (OWASP API3:2023) by intercepting raw API responses and comparing them  |
| `exploiting-http-request-smuggling` | 348 | 10.8 | Detects and exploits HTTP request smuggling caused by Content-Length/Transfer-Encoding parsing discrepancies b |
| `exploiting-idor-vulnerabilities` | 314 | 11.6 | Identifies and exploits Insecure Direct Object Reference (IDOR) vulnerabilities by manipulating object identif |
| `exploiting-insecure-data-storage-in-mobile` | 229 | 7.6 | Identifies and exploits insecure local data storage vulnerabilities in Android and iOS mobile applications inc |
| `exploiting-insecure-deserialization` | 333 | 11.5 | Identifying and exploiting insecure deserialization vulnerabilities in Java, PHP, Python, and .NET application |
| `exploiting-ipv6-vulnerabilities` | 312 | 11.3 | Identifies and exploits IPv6-specific vulnerabilities including SLAAC spoofing, Router Advertisement flooding, |
| `exploiting-jwt-algorithm-confusion-attack` | 470 | 18.4 | Exploits JWT algorithm confusion where the server's verification library trusts the alg named in the token hea |
| `exploiting-kerberoasting-with-impacket` | 235 | 7.7 | Performs Kerberoasting (MITRE ATT&CK T1558.003) using Impacket's GetUserSPNs.py to request Kerberos TGS ticket |
| `exploiting-mass-assignment-in-rest-apis` | 243 | 9.2 | Discovers and exploits mass assignment (autobinding) in REST APIs by injecting unexpected or hidden parameters |
| `exploiting-ms17-010-eternalblue-vulnerability` | 112 | 3.8 | Detects and exploits MS17-010 (EternalBlue), a critical remote code execution flaw in Microsoft's SMBv1 implem |
| `exploiting-nopac-cve-2021-42278-42287` | 203 | 8.1 | Exploits the noPac Active Directory privilege-escalation chain (CVE-2021-42278 sAMAccountName spoofing plus CV |
| `exploiting-nosql-injection-vulnerabilities` | 222 | 8.1 | Detects and exploits NoSQL injection vulnerabilities in MongoDB, CouchDB, and similar databases to demonstrate |
| `exploiting-oauth-misconfiguration` | 317 | 12.0 | Identifying and exploiting OAuth 2.0 and OpenID Connect misconfigurations including redirect URI manipulation, |
| `exploiting-prototype-pollution-in-javascript` | 242 | 9.2 | Detects and exploits JavaScript prototype pollution vulnerabilities in client-side and server-side (Node.js) a |
| `exploiting-race-condition-vulnerabilities` | 249 | 8.8 | Detects and exploits race condition (TOCTOU) vulnerabilities in web applications using Burp Suite's Turbo Intr |
| `exploiting-server-side-request-forgery` | 355 | 12.6 | Identifying and exploiting SSRF vulnerabilities to access internal services, cloud metadata, and restricted ne |
| `exploiting-smb-vulnerabilities-with-metasploit` | 258 | 10.1 | Identifies and exploits SMB protocol vulnerabilities using Metasploit Framework during authorized penetration  |
| `exploiting-sql-injection-vulnerabilities` | 206 | 12.4 | Identifies and exploits SQL injection vulnerabilities in web applications during authorized penetration tests  |
| `exploiting-sql-injection-with-sqlmap` | 258 | 9.0 | Detecting and exploiting SQL injection vulnerabilities using sqlmap to extract database contents during author |
| `exploiting-template-injection-vulnerabilities` | 324 | 12.2 | Detects and exploits Server-Side Template Injection (SSTI) vulnerabilities across Jinja2, Twig, Freemarker, an |
| `exploiting-type-juggling-vulnerabilities` | 275 | 9.6 | Exploits PHP type juggling vulnerabilities caused by loose (==) comparison operators to bypass authentication, |
| `exploiting-vulnerabilities-with-metasploit-framework` | 219 | 7.3 | Uses the Metasploit Framework (msfconsole and its exploit, auxiliary, and post-exploitation modules) to valida |
| `exploiting-websocket-vulnerabilities` | 425 | 14.0 | Testing WebSocket implementations for authentication bypass, cross-site hijacking, injection attacks, and inse |
| `exploiting-zerologon-vulnerability-cve-2020-1472` | 229 | 7.7 | Exploits the Zerologon vulnerability (CVE-2020-1472) in the Netlogon Remote Protocol using Impacket to reset a |
| `extracting-browser-history-artifacts` | 355 | 11.4 | Extracts and analyzes browser history, cookies, cache, downloads, and bookmarks from Chrome, Firefox, and Edge |
| `extracting-config-from-agent-tesla-rat` | 208 | 7.1 | Extracts embedded configuration from Agent Tesla RAT samples, including SMTP/FTP/Telegram exfiltration credent |
| `extracting-credentials-from-memory-dump` | 372 | 13.1 | Extracts cached credentials, password hashes, Kerberos tickets, and authentication tokens from Windows memory  |
| `extracting-iocs-from-malware-samples` | 397 | 13.9 | Extracts indicators of compromise (IOCs) from malware samples, including file hashes, network indicators (IPs, |
| `extracting-memory-artifacts-with-rekall` | 95 | 2.5 | Uses Rekall memory forensics framework to analyze memory dumps for process hollowing, injected code via VAD an |
| `extracting-windows-event-logs-artifacts` | 344 | 12.8 | Extract, parse, and analyze Windows Event Logs (EVTX) using Chainsaw, Hayabusa, and EvtxECmd to detect lateral |
| `fleet-hunting-with-velociraptor` | 198 | 8.7 | Deploy a Velociraptor server and agents, then author VQL (Velociraptor Query Language) artifacts and run them  |
| `generating-and-analyzing-sboms` | 187 | 7.4 | Generate CycloneDX and SPDX SBOMs from container images and filesystems with Syft, correlate them to CVEs with |
| `generating-forensic-timelines-with-hayabusa` | 170 | 8.6 | Run Hayabusa against collected Windows EVTX files to apply Sigma detection rules and produce a prioritized, ch |
| `generating-threat-intelligence-reports` | 156 | 7.6 | Generates structured cyber threat intelligence reports at strategic, operational, and tactical levels tailored |
| `hardening-docker-containers-for-production` | 244 | 7.1 | Hardens Dockerfiles, images, and per-container runtime settings against the CIS Docker Benchmark v1.8.0: non-r |
| `hardening-docker-daemon-configuration` | 338 | 8.4 | Hardens the Docker daemon (dockerd) through /etc/docker/daemon.json with user namespace remapping, TLS client  |
| `hardening-linux-endpoint-with-cis-benchmark` | 239 | 7.1 | Hardens Linux endpoints using CIS Benchmark recommendations for Ubuntu, RHEL, and CentOS to reduce attack surf |
| `hardening-windows-endpoint-with-cis-benchmark` | 211 | 8.7 | Hardens Windows endpoints using CIS (Center for Internet Security) Benchmark recommendations to reduce attack  |
| `hunting-advanced-persistent-threats` | 147 | 6.6 | Proactively hunts for Advanced Persistent Threat (APT) activity within enterprise environments using hypothesi |
| `hunting-bootkits-in-efi-system-partition` | 223 | 12.5 | Baseline the EFI System Partition and hunt malicious EFI binaries such as ESPecter, BlackLotus, Bootkitty, and |
| `hunting-credential-stuffing-attacks` | 106 | 2.9 | Detects credential stuffing attacks by analyzing authentication logs for login velocity anomalies, ASN diversi |
| `hunting-evtx-with-chainsaw` | 178 | 8.3 | Run Chainsaw against collected Windows EVTX files to hunt with the SigmaHQ rule corpus, built-in detection rul |
| `hunting-for-anomalous-powershell-execution` | 82 | 2.5 | Hunt for malicious PowerShell activity by analyzing Script Block Logging (Event 4104), Module Logging (Event 4 |
| `hunting-for-beaconing-with-frequency-analysis` | 178 | 7.8 | Identify command-and-control beaconing patterns in network traffic by applying statistical frequency analysis, |
| `hunting-for-cobalt-strike-beacons` | 72 | 2.9 | Detect Cobalt Strike beacon command-and-control traffic using default TLS certificate signatures (serial 8BB00 |
| `hunting-for-command-and-control-beaconing` | 121 | 4.4 | Detect C2 beaconing patterns in network traffic using frequency analysis, jitter detection, and domain reputat |
| `hunting-for-data-exfiltration-indicators` | 121 | 4.7 | Hunt for data exfiltration by analyzing Zeek and Suricata network telemetry for unusual data flows, DNS tunnel |
| `hunting-for-data-staging-before-exfiltration` | 73 | 3.1 | Detect data-staging activity (MITRE ATT&CK T1074) by analyzing EDR/Sysmon process-creation and file-system tel |
| `hunting-for-dcom-lateral-movement` | 687 | 29.1 | Hunt for DCOM-based lateral movement (MITRE ATT&CK T1021.003) by detecting abuse of MMC20.Application, ShellBr |
| `hunting-for-dcsync-attacks` | 99 | 3.5 | Detect DCSync attacks (MITRE ATT&CK T1003.006) by analyzing Windows Event ID 4662 (AccessMask 0x100) for DS-Re |
| `hunting-for-defense-evasion-via-timestomping` | 360 | 14.3 | Detect NTFS timestamp manipulation (MITRE T1070.006) by comparing $STANDARD_INFORMATION vs $FILE_NAME timestam |
| `hunting-for-dns-based-persistence` | 78 | 3.1 | Hunts for DNS-based persistence mechanisms such as DNS hijacking, dangling CNAME records enabling subdomain ta |
| `hunting-for-dns-tunneling-with-zeek` | 157 | 6.5 | Detects DNS tunneling and covert-channel data exfiltration by analyzing Zeek dns.log for high-entropy subdomai |
| `hunting-for-domain-fronting-c2-traffic` | 73 | 2.7 | Detects domain fronting C2 traffic by analyzing SNI-vs-HTTP-Host-header mismatches in proxy logs and inspectin |
| `hunting-for-lateral-movement-via-wmi` | 71 | 2.6 | Detects WMI-based lateral movement (e.g. wmic process call create, Win32_Process.Create()) by analyzing Window |
| `hunting-for-living-off-the-cloud-techniques` | 108 | 3.6 | Hunts for adversary abuse of legitimate cloud services (Azure, AWS, GCP, and SaaS platforms) for command-and-c |
| `hunting-for-living-off-the-land-binaries` | 125 | 5.5 | Proactively hunts for adversary abuse of legitimate, signed system binaries (LOLBins) used to execute maliciou |
| `hunting-for-lolbins-execution-in-endpoint-logs` | 185 | 7.9 | Hunts for LOLBins (Living Off the Land Binaries) abuse, mapped to MITRE T1218, by analyzing endpoint process-c |
| `hunting-for-ntlm-relay-attacks` | 74 | 2.8 | Detects NTLM relay attacks (MITRE T1557.001) by analyzing Windows Event ID 4624 logon type 3 with NTLMSSP auth |
| `hunting-for-persistence-mechanisms-in-windows` | 120 | 4.7 | Systematically hunts for adversary persistence mechanisms across Windows endpoints, covering registry Run/RunO |
| `hunting-for-persistence-via-wmi-subscriptions` | 152 | 6.0 | Hunts for adversary persistence via WMI event subscriptions (MITRE T1546.003) by monitoring the creation of WM |
| `hunting-for-process-injection-techniques` | 77 | 2.8 | Detects process injection techniques (MITRE T1055) — including CreateRemoteThread injection, process hollowing |
| `hunting-for-registry-persistence-mechanisms` | 108 | 3.6 | Hunts for registry-based persistence mechanisms (MITRE T1547) in Windows environments, including Run/RunOnce k |
| `hunting-for-registry-run-key-persistence` | 74 | 3.3 | Detect MITRE ATT&CK T1547.001 registry Run key persistence by analyzing Sysmon Event ID 13 logs and registry q |
| `hunting-for-scheduled-task-persistence` | 102 | 3.5 | Runs a hypothesis-driven threat hunt for Windows Scheduled Task persistence (T1053), guiding SIEM/EDR queries  |
| `hunting-for-shadow-copy-deletion` | 103 | 3.5 | Runs a hypothesis-driven threat hunt for Volume Shadow Copy deletion (T1490) by querying SIEM/EDR telemetry fo |
| `hunting-for-spearphishing-indicators` | 131 | 3.9 | Hunt for spearphishing campaign indicators across email logs, endpoint telemetry, and network data to detect t |
| `hunting-for-startup-folder-persistence` | 70 | 2.6 | Detects T1547.001 startup folder persistence by monitoring Windows startup directories for suspicious file cre |
| `hunting-for-supply-chain-compromise` | 102 | 3.5 | Runs a hypothesis-driven threat hunt for supply-chain compromise (T1195) by querying SIEM/EDR logs for trojani |
| `hunting-for-suspicious-scheduled-tasks` | 108 | 4.8 | Hunts for adversary persistence and execution via Windows scheduled tasks (T1053.005) by analyzing Security Ev |
| `hunting-for-t1098-account-manipulation` | 72 | 2.9 | Hunts for MITRE ATT&CK T1098 account manipulation - shadow admin creation, SID history injection, group member |
| `hunting-for-unusual-network-connections` | 102 | 3.6 | Runs a hypothesis-driven threat hunt for command-and-control activity (T1071) by querying SIEM/EDR network tel |
| `hunting-for-unusual-service-installations` | 71 | 2.6 | Detects suspicious Windows service installations (MITRE ATT&CK T1543.003) by parsing System event log Event ID |
| `hunting-for-webshell-activity` | 103 | 3.5 | Runs a hypothesis-driven threat hunt for web shell deployment (T1505.003) on internet-facing servers by analyz |
| `hunting-saas-sso-token-abuse` | 223 | 11.3 | Hunts for stolen-session and OAuth/PRT token replay (T1550.001) by correlating Microsoft Entra ID SigninLogs S |
| `implementing-aes-encryption-for-data-at-rest` | 112 | 4.1 | Guides implementing AES-256 encryption in GCM mode (FIPS 197) for files and data stores at rest, covering key  |
| `implementing-alert-fatigue-reduction` | 338 | 12.1 | Implements strategies to reduce SOC alert fatigue by tuning detection rules, consolidating duplicate alerts, i |
| `implementing-anti-phishing-training-program` | 131 | 5.0 | Guides designing, deploying, and measuring an anti-phishing security awareness program - baseline phishing sim |
| `implementing-anti-ransomware-group-policy` | 245 | 9.3 | Configures Windows Group Policy Objects to block ransomware execution and lateral spread, covering AppLocker r |
| `implementing-api-abuse-detection-with-rate-limiting` | 400 | 13.1 | Implements API abuse detection using token bucket, sliding window, and fixed window rate-limiting algorithms b |
| `implementing-api-gateway-security-controls` | 469 | 15.2 | Configures API gateways such as Kong, AWS API Gateway, Azure APIM, or Apigee as a centralized security enforce |
| `implementing-api-key-security-controls` | 415 | 15.4 | Implements secure API key generation with sufficient entropy, server-side hashing (SHA-256/bcrypt) instead of  |
| `implementing-api-rate-limiting-and-throttling` | 482 | 17.5 | Implements API rate limiting and throttling with token bucket, sliding window, and fixed window algorithms, co |
| `implementing-api-schema-validation-security` | 439 | 13.5 | Implements API schema validation using OpenAPI Specification and JSON Schema documents, enforced both at the A |
| `implementing-api-security-posture-management` | 419 | 14.6 | Implements API Security Posture Management (API-SPM) to continuously discover, classify, and risk-score APIs - |
| `implementing-api-security-testing-with-42crunch` | 365 | 10.8 | Implements API security testing on the 42Crunch platform, combining API Audit for static analysis of OpenAPI d |
| `implementing-api-threat-protection-with-apigee` | 338 | 10.9 | Implements API threat protection using Google Apigee reverse-proxy policies, including JSON/XML threat protect |
| `implementing-application-whitelisting-with-applocker` | 261 | 10.2 | Implements application whitelisting using Windows AppLocker to restrict unauthorized software execution on end |
| `implementing-aqua-security-for-container-scanning` | 266 | 7.3 | Deploy Aqua Security's Trivy scanner to detect vulnerabilities, misconfigurations, secrets, and license issues |
| `implementing-attack-path-analysis-with-xm-cyber` | 266 | 10.7 | Deploys XM Cyber's continuous exposure management platform to build attack graphs that chain vulnerabilities,  |
| `implementing-attack-surface-management` | 230 | 7.0 | Implements external attack surface management (EASM) using Shodan, Censys, and ProjectDiscovery tools (subfind |
| `implementing-aws-config-rules-for-compliance` | 351 | 13.4 | Implements AWS Config managed and custom rules for continuous compliance monitoring of AWS resources aligned t |
| `implementing-aws-iam-permission-boundaries` | 272 | 8.9 | Configures AWS IAM permission boundaries that cap the maximum permissions an identity-based policy can grant t |
| `implementing-aws-macie-for-data-classification` | 332 | 8.3 | Enable and configure Amazon Macie via AWS CLI/Terraform to discover, classify, and protect sensitive data (PII |
| `implementing-aws-nitro-enclave-security` | 462 | 21.3 | Build AWS Nitro Enclave confidential computing environments using nitro-cli to create enclave images, configur |
| `implementing-aws-security-hub` | 235 | 9.7 | Deploy AWS Security Hub as a centralized CSPM platform, backed by AWS Config, aggregating findings from GuardD |
| `implementing-aws-security-hub-compliance` | 319 | 12.1 | Deploy AWS Security Hub, backed by AWS Config, to aggregate findings from GuardDuty, Inspector, Macie, Firewal |
| `implementing-azure-ad-privileged-identity-management` | 274 | 10.3 | Configure Microsoft Entra Privileged Identity Management (PIM) to convert standing privileged assignments into |
| `implementing-azure-defender-for-cloud` | 330 | 12.1 | Enable Microsoft Defender for Cloud (CSPM + CWPP) across VMs, containers, SQL, storage, and Key Vault, using A |
| `implementing-beyondcorp-zero-trust-access-model` | 341 | 13.5 | Implement Google's BeyondCorp zero trust access model using Cloud IAP, Access Context Manager, Endpoint Verifi |
| `implementing-bgp-security-with-rpki` | 340 | 12.1 | Implement RPKI-based BGP route origin validation by creating Route Origin Authorizations (ROAs) at RIRs (ARIN, |
| `implementing-browser-isolation-for-zero-trust` | 423 | 13.6 | Deploys remote browser isolation (RBI) as a core component of a Zero Trust architecture. Implements isolation  |
| `implementing-canary-tokens-for-network-intrusion` | 336 | 12.1 | Deploys DNS, HTTP, and AWS API key canary tokens across network infrastructure to detect unauthorized access a |
| `implementing-cisa-zero-trust-maturity-model` | 352 | 12.1 | Assess, gap-analyze, and progressively implement the CISA Zero Trust Maturity Model v2.0 across five pillars ( |
| `implementing-cloud-dlp-for-data-protection` | 467 | 16.2 | Implement cloud DLP using Amazon Macie, Google Cloud DLP API, Microsoft Purview, Azure Information Protection, |
| `implementing-cloud-security-posture-management` | 304 | 11.8 | Continuously monitor multi-cloud environments (AWS, Azure, GCP) for misconfigurations, compliance violations,  |
| `implementing-cloud-trail-log-analysis` | 353 | 13.3 | Implementing AWS CloudTrail log analysis for security monitoring, threat detection, and forensic investigation |
| `implementing-cloud-vulnerability-posture-management` | 237 | 7.6 | Implement multi-cloud CSPM to detect cloud-native misconfigurations and vulnerabilities (IAM over-permissions, |
| `implementing-cloud-waf-rules` | 320 | 11.2 | Deploys and tunes Web Application Firewall rules on AWS WAF, Azure WAF, and Cloudflare, covering managed rule  |
| `implementing-cloud-workload-protection` | 85 | 2.3 | Implements cloud workload protection using boto3 and google-cloud APIs for runtime security monitoring, proces |
| `implementing-code-signing-for-artifacts` | 236 | 7.2 | Implements code signing for build artifacts (binaries, packages, containers) using GPG, Sigstore, and platform |
| `implementing-conditional-access-policies-azure-ad` | 75 | 2.7 | Configures Microsoft Entra ID (Azure AD) Conditional Access policies for zero trust access control, covering s |
| `implementing-conduit-security-for-ot-remote-access` | 379 | 13.1 | Implements secure conduit architecture for OT remote access under the IEC 62443 zones-and-conduits model, depl |
| `implementing-container-image-minimal-base-with-distroless` | 222 | 6.6 | Reduces container attack surface by building application images on Google distroless base images that ship onl |
| `implementing-container-network-policies-with-calico` | 73 | 2.7 | Uses Calico's own policy CRDs beyond the upstream Kubernetes API - GlobalNetworkPolicy, HostEndpoint, NetworkS |
| `implementing-continuous-security-validation-with-bas` | 269 | 9.7 | Deploys Breach and Attack Simulation (BAS) platforms such as SafeBreach, AttackIQ, Picus, Cymulate, Pentera, o |
| `implementing-data-loss-prevention-with-microsoft-purview` | 602 | 30.7 | Implements DLP policies using Microsoft Purview PowerShell cmdlets and the Graph API to protect data across Ex |
| `implementing-ddos-mitigation-with-cloudflare` | 453 | 14.7 | Configure Cloudflare DDoS protection with managed rulesets, rate limiting, WAF rules, Bot Management, and orig |
| `implementing-deception-based-detection-with-canarytoken` | 68 | 2.3 | Deploys and monitors Canary Tokens via the Thinkst Canary REST API for deception-based breach detection, progr |
| `implementing-delinea-secret-server-for-pam` | 451 | 16.7 | Implements Delinea Secret Server for privileged access management, covering secret vault configuration, role-b |
| `implementing-device-posture-assessment-in-zero-trust` | 459 | 16.0 | Implements device posture assessment as a zero trust access control by integrating endpoint health signals fro |
| `implementing-devsecops-security-scanning` | 393 | 12.0 | Integrates SAST, DAST, and SCA into CI/CD pipelines using Semgrep for SAST, Trivy for SCA and container scanni |
| `implementing-diamond-model-analysis` | 186 | 6.4 | The Diamond Model of Intrusion Analysis provides a structured framework for analyzing cyber intrusions by exam |
| `implementing-digital-signatures-with-ed25519` | 92 | 3.4 | Implements digital signatures using the Ed25519 algorithm (Curve25519), covering key-pair generation, signing, |
| `implementing-disk-encryption-with-bitlocker` | 229 | 8.7 | Implements full disk encryption using Microsoft BitLocker on Windows endpoints to protect data at rest from un |
| `implementing-dmarc-dkim-spf-email-security` | 130 | 4.5 | Configures SPF, DKIM, and DMARC DNS TXT records to authenticate outbound email, prevent domain spoofing, and e |
| `implementing-dragos-platform-for-ot-monitoring` | 371 | 13.6 | Deploys and configures Dragos Platform sensors and detection analytics for OT/ICS network monitoring, using in |
| `implementing-ebpf-security-monitoring` | 391 | 9.2 | Implements eBPF-based security monitoring using Cilium Tetragon for real-time process execution tracking, netw |
| `implementing-email-sandboxing-with-proofpoint` | 114 | 4.2 | Email sandboxing detonates suspicious attachments and URLs in isolated environments to detect zero-day malware |
| `implementing-end-to-end-encryption-for-messaging` | 87 | 3.3 | Implements a simplified Signal Protocol-style end-to-end encryption scheme for messaging, covering key exchang |
| `implementing-endpoint-detection-with-wazuh` | 72 | 2.3 | Deploys and configures Wazuh SIEM/XDR for endpoint detection, covering agent authentication and management, cu |
| `implementing-endpoint-dlp-controls` | 177 | 5.8 | Implements endpoint Data Loss Prevention (DLP) controls to detect and prevent sensitive data exfiltration thro |
| `implementing-envelope-encryption-with-aws-kms` | 101 | 3.7 | Implements envelope encryption with AWS KMS, encrypting data locally with a data encryption key (DEK) and prot |
| `implementing-epss-score-for-vulnerability-prioritization` | 222 | 7.4 | Queries FIRST's Exploit Prediction Scoring System (EPSS) API to fetch exploitation-probability and percentile  |
| `implementing-file-integrity-monitoring-with-aide` | 64 | 2.5 | Configures AIDE (Advanced Intrusion Detection Environment) for file integrity monitoring on Linux, covering ba |
| `implementing-fuzz-testing-in-cicd-with-aflplusplus` | 299 | 8.3 | Integrates AFL++ coverage-guided fuzzing into CI/CD pipelines, covering harness construction, AFL++/AddressSan |
| `implementing-gcp-binary-authorization` | 289 | 7.7 | Implements GCP Binary Authorization end to end, including creating KMS-backed attestors, Container Analysis no |
| `implementing-gcp-organization-policy-constraints` | 277 | 7.0 | Implements GCP Organization Policy constraints via gcloud and Terraform, such as restricting external IPs, res |
| `implementing-gcp-vpc-firewall-rules` | 315 | 11.8 | Implements and audits GCP VPC firewall rules using gcloud, covering auditing overly permissive rules, creating |
| `implementing-gdpr-data-protection-controls` | 195 | 8.3 | Implements GDPR (EU 2016/679) technical and organizational measures — privacy by design/default, DPIAs, data s |
| `implementing-gdpr-data-subject-access-request` | 304 | 9.7 | Automates GDPR Data Subject Access Request (DSAR) workflows including identity verification, PII discovery acr |
| `implementing-github-advanced-security-for-code-scanning` | 213 | 8.9 | Configures GitHub Advanced Security (code scanning with CodeQL, secret scanning, dependency review, and Depend |
| `implementing-google-workspace-admin-security` | 517 | 16.9 | Hardens a Google Workspace tenant via Admin Console configuration: phishing-resistant MFA enforcement, DLP pol |
| `implementing-google-workspace-phishing-protection` | 139 | 5.6 | Configures Google Workspace advanced phishing and malware protection settings in the Admin Console — pre-deliv |
| `implementing-google-workspace-sso-configuration` | 215 | 7.8 | Configures SAML 2.0 single sign-on for Google Workspace against a third-party identity provider (Okta, Azure A |
| `implementing-hardware-security-key-authentication` | 231 | 17.5 | Builds a FIDO2/WebAuthn relying party server with the python-fido2 library, covering registration and authenti |
| `implementing-hashicorp-vault-dynamic-secrets` | 631 | 20.5 | Configures HashiCorp Vault dynamic secrets engines for database credentials, AWS IAM keys, and PKI certificate |
| `implementing-hipaa-security-rule-safeguards` | 143 | 9.5 | Implement the HIPAA Security Rule (45 CFR Part 164 Subpart C) to protect electronic protected health informati |
| `implementing-honeypot-for-ransomware-detection` | 405 | 15.3 | Deploys canary files, honeypot shares, and decoy systems to detect ransomware activity at the earliest possibl |
| `implementing-honeytokens-for-breach-detection` | 84 | 2.3 | Deploys canary tokens and honeytokens (fake AWS credentials, DNS canaries, document beacons, database records) |
| `implementing-ics-firewall-with-tofino` | 361 | 12.0 | Deploys and configures Tofino industrial firewalls (Belden/Hirschmann) to protect SCADA systems and PLCs, usin |
| `implementing-identity-governance-with-sailpoint` | 102 | 3.1 | Deploys SailPoint IdentityNow or IdentityIQ for identity governance and administration, covering identity life |
| `implementing-identity-verification-for-zero-trust` | 250 | 9.7 | Implements continuous, risk-adaptive identity verification for zero trust using phishing-resistant MFA (FIDO2/ |
| `implementing-iec-62443-security-zones` | 536 | 19.7 | Designs security zones and conduits for industrial control systems (IACS) per IEC 62443-3-2 — risk-based zone  |
| `implementing-image-provenance-verification-with-cosign` | 339 | 8.8 | Signs and verifies container image provenance with Sigstore Cosign, covering key-based and keyless OIDC signin |
| `implementing-immutable-backup-with-restic` | 111 | 4.1 | Implements ransomware-resistant backups using restic with S3-compatible Object Lock (AWS S3, MinIO, Backblaze  |
| `implementing-infrastructure-as-code-security-scanning` | 268 | 8.5 | Implements automated security scanning for Infrastructure as Code using Checkov, tfsec, and KICS to detect mis |
| `implementing-iso-27001-information-security-management` | 184 | 7.9 | Guides implementation of an ISO/IEC 27001:2022 Information Security Management System (ISMS) end to end: gap a |
| `implementing-just-in-time-access-provisioning` | 136 | 5.1 | Implements Just-In-Time (JIT) access provisioning to eliminate standing privileges by granting temporary, time |
| `implementing-jwt-signing-and-verification` | 96 | 3.4 | Implements secure JWT (RFC 7519) signing and verification using HMAC-SHA256, RSA-PSS, ES256, and EdDSA, includ |
| `implementing-kubernetes-network-policy-with-calico` | 341 | 7.8 | Installs Calico as the cluster CNI and writes standard Kubernetes NetworkPolicy under it, covering default-den |
| `implementing-kubernetes-pod-security-standards` | 283 | 9.0 | Chooses and applies the correct Kubernetes Pod Security Standard (Privileged, Baseline, Restricted) for a work |
| `implementing-llm-guardrails-for-security` | 232 | 8.7 | Implements input/output validation guardrails for LLM applications using NVIDIA NeMo Guardrails (Colang), cust |
| `implementing-log-forwarding-with-fluentd` | 73 | 2.7 | Configures Fluent Bit as an endpoint log forwarder and Fluentd as the central aggregator for centralized log c |
| `implementing-log-integrity-with-blockchain` | 74 | 2.4 | Builds an append-only log integrity chain using SHA-256 hash chaining, where each entry incorporates the previ |
| `implementing-memory-protection-with-dep-aslr` | 110 | 3.9 | Implements memory protection mechanisms including DEP (Data Execution Prevention), ASLR (Address Space Layout  |
| `implementing-microsegmentation-with-guardicore` | 353 | 12.2 | Implements microsegmentation with Akamai Guardicore Segmentation to map application dependencies, visualize ea |
| `implementing-mimecast-targeted-attack-protection` | 163 | 6.9 | Deploys and configures Mimecast Targeted Threat Protection (TTP) modules -- URL Protect (click-time URL rewrit |
| `implementing-mitre-attack-coverage-mapping` | 296 | 9.0 | Implement MITRE ATT&CK coverage mapping to identify detection gaps, prioritize rule development, and measure S |
| `implementing-mobile-application-management` | 184 | 6.5 | Implements Mobile Application Management (MAM) policies to protect enterprise data on managed and unmanaged mo |
| `implementing-mtls-for-zero-trust-services` | 85 | 2.5 | Configures mutual TLS (mTLS) authentication between microservices using Python cryptography library for certif |
| `implementing-nerc-cip-compliance-controls` | 435 | 16.8 | Implements NERC CIP controls for Bulk Electric System (BES) cyber systems: asset categorization (CIP-002), ele |
| `implementing-network-access-control` | 445 | 14.7 | Implements 802.1X port-based network access control using RADIUS authentication, PacketFence NAC, and switch c |
| `implementing-network-access-control-with-cisco-ise` | 352 | 11.3 | Deploys Cisco Identity Services Engine (ISE) as a RADIUS policy server for 802.1X wired and wireless authentic |
| `implementing-network-deception-with-honeypots` | 93 | 3.0 | Deploy and manage network honeypots using OpenCanary, T-Pot, or Cowrie to detect unauthorized access, lateral  |
| `implementing-network-intrusion-prevention-with-suricata` | 379 | 11.7 | Deploys and configures Suricata as an inline network intrusion prevention system, covering IPS mode setup (NFQ |
| `implementing-network-policies-for-kubernetes` | 245 | 5.9 | Writes portable upstream Kubernetes NetworkPolicy YAML - default-deny-all, DNS egress, namespace and pod selec |
| `implementing-network-segmentation-for-ot` | 497 | 17.5 | Implements OT network segmentation using VLANs, OT-aware firewalls, data diodes, and IEC 62443 zone/conduit ar |
| `implementing-network-segmentation-with-firewall-zones` | 350 | 13.2 | Designs and implements network segmentation using firewall security zones, VLANs, inter-zone ACLs, and workloa |
| `implementing-network-traffic-analysis-with-arkime` | 75 | 2.2 | Queries Arkime (formerly Moloch) full packet capture via its API to search sessions, download PCAPs, detect C2 |
| `implementing-network-traffic-baselining` | 67 | 2.5 | Builds network traffic baselines from NetFlow/IPFIX CSV or JSON exports using Python pandas, computing hourly/ |
| `implementing-next-generation-firewall-with-palo-alto` | 285 | 12.2 | Configures and deploys Palo Alto Networks next-generation firewalls end-to-end, covering App-ID application-aw |
| `implementing-opa-gatekeeper-for-policy-enforcement` | 400 | 10.4 | Deploys OPA Gatekeeper via Helm as a Kubernetes admission controller and writes ConstraintTemplates with Rego  |
| `implementing-ot-incident-response-playbook` | 395 | 16.5 | Develops OT-specific incident response playbooks using a SANS PICERL-based Python engine that classifies incid |
| `implementing-ot-network-traffic-analysis-with-nozomi` | 282 | 9.8 | Deploy Nozomi Networks Guardian sensors for passive OT network traffic analysis, providing asset visibility, b |
| `implementing-pam-for-database-access` | 102 | 3.1 | Deploy privileged access management for database systems including Oracle, SQL Server, PostgreSQL, and MySQL,  |
| `implementing-passwordless-auth-with-microsoft-entra` | 581 | 21.1 | Implements passwordless authentication using Microsoft Entra ID with FIDO2 security keys, Windows Hello for Bu |
| `implementing-passwordless-authentication-with-fido2` | 84 | 2.8 | Deploy FIDO2/WebAuthn passwordless authentication using security keys and platform authenticators, covering We |
| `implementing-patch-management-for-ot-systems` | 353 | 12.4 | Implements a structured patch management program for OT/ICS environments where IT-style patching can cause pro |
| `implementing-patch-management-workflow` | 322 | 10.5 | Patch management is the systematic process of identifying, testing, deploying, and verifying software updates  |
| `implementing-pci-dss-compliance-controls` | 151 | 6.4 | Implements PCI DSS 4.0.1's 12 requirements across 6 control objectives for organizations that store, process,  |
| `implementing-pod-security-admission-controller` | 342 | 9.6 | Configures and operates the Kubernetes Pod Security Admission (PSA) controller that enforces Pod Security Stan |
| `implementing-policy-as-code-with-open-policy-agent` | 333 | 10.1 | Implements policy-as-code enforcement with Open Policy Agent (OPA) and Gatekeeper for Kubernetes and CI/CD pip |
| `implementing-privileged-access-management-with-cyberark` | 181 | 7.2 | Deploy CyberArk Privileged Access Management to discover, vault, rotate, and monitor privileged credentials ac |
| `implementing-privileged-access-workstation` | 68 | 2.5 | Design and implement Privileged Access Workstations (PAWs) using the tiered administration model, with device  |
| `implementing-privileged-session-monitoring` | 341 | 11.6 | Implements privileged session monitoring and recording using PAM solutions, focusing on CyberArk Privileged Se |
| `implementing-proofpoint-email-security-gateway` | 166 | 6.9 | Deploy and configure Proofpoint Email Protection as a secure email gateway to detect and block phishing, malwa |
| `implementing-purdue-model-network-segmentation` | 452 | 17.1 | Implement network segmentation based on the Purdue Enterprise Reference Architecture (PERA) model, separating  |
| `implementing-ransomware-backup-strategy` | 320 | 12.2 | Designs a ransomware-resilient backup strategy using the 3-2-1-1-0 methodology (3 copies, 2 media types, 1 off |
| `implementing-ransomware-kill-switch-detection` | 249 | 9.5 | Analyzes ransomware kill switch mechanisms, including mutex-based execution guards, domain-based kill switches |
| `implementing-rapid7-insightvm-for-scanning` | 368 | 12.0 | Deploy and configure Rapid7 InsightVM Security Console and Scan Engines, including scan templates, credentiale |
| `implementing-rbac-hardening-for-kubernetes` | 273 | 7.8 | Hardens Kubernetes RBAC by designing least-privilege Roles and ClusterRoles, auditing RoleBindings, eliminatin |
| `implementing-rsa-key-pair-management` | 103 | 3.6 | Generates, stores, rotates, and manages RSA key pairs following NIST SP 800-57 guidelines, covering serializat |
| `implementing-runtime-application-self-protection` | 79 | 2.9 | Deploy Runtime Application Self-Protection (RASP) agents to detect and block attacks from within application r |
| `implementing-runtime-security-with-tetragon` | 307 | 8.3 | Implements eBPF-based runtime observability and in-kernel enforcement in Kubernetes with Cilium Tetragon, moni |
| `implementing-saml-sso-with-okta` | 175 | 6.6 | Implement SAML 2.0 Single Sign-On using Okta as the Identity Provider, covering SP-initiated and IdP-initiated |
| `implementing-scim-provisioning-with-okta` | 257 | 9.0 | Implement automated user lifecycle provisioning and deprovisioning using the SCIM 2.0 protocol with Okta as th |
| `implementing-secret-scanning-with-gitleaks` | 346 | 11.1 | This skill covers implementing Gitleaks for detecting and preventing hardcoded secrets in git repositories. It |
| `implementing-secrets-management-with-vault` | 349 | 12.3 | Deploy HashiCorp Vault for centralized secrets management, covering dynamic secret generation for databases an |
| `implementing-secrets-scanning-in-ci-cd` | 93 | 3.7 | Integrate gitleaks and trufflehog into CI/CD pipelines to detect leaked secrets before deployment |
| `implementing-security-chaos-engineering` | 98 | 2.5 | Implements security chaos engineering experiments that deliberately disable or degrade security controls to ve |
| `implementing-security-information-sharing-with-stix2` | 418 | 12.8 | Create, validate, and share STIX 2.1 threat intelligence objects (indicators, malware, campaigns, relationship |
| `implementing-security-monitoring-with-datadog` | 425 | 14.3 | Implements security monitoring using Datadog Cloud SIEM, Cloud Security Management (CSM), and Workload Protect |
| `implementing-semgrep-for-custom-sast-rules` | 332 | 7.5 | Write custom Semgrep SAST rules in YAML to detect application-specific vulnerabilities, enforce coding standar |
| `implementing-siem-correlation-rules-for-apt` | 95 | 3.1 | Write multi-event correlation rules in Splunk SPL and Sigma format that detect APT lateral movement by chainin |
| `implementing-siem-use-case-tuning` | 69 | 2.6 | Tune SIEM detection rules in Splunk and Elastic to reduce false positives by analyzing alert volumes, creating |
| `implementing-siem-use-cases-for-detection` | 328 | 11.1 | Implements SIEM detection use cases by designing correlation rules, threshold alerts, and behavioral analytics |
| `implementing-sigstore-for-software-signing` | 203 | 12.6 | Implements Sigstore-based software signing and verification using Cosign keyless signing, Rekor transparency l |
| `implementing-soar-automation-with-phantom` | 421 | 14.3 | Implements Security Orchestration, Automation, and Response (SOAR) workflows using Splunk SOAR (formerly Phant |
| `implementing-soar-playbook-for-phishing` | 127 | 4.8 | Automates phishing incident response by calling the Splunk SOAR (Phantom) REST API to create containers, attac |
| `implementing-soar-playbook-with-palo-alto-xsoar` | 347 | 9.4 | Build automated incident response playbooks in Cortex XSOAR (Demisto) using its YAML playbook structure, integ |
| `implementing-stix-taxii-feed-integration` | 319 | 10.4 | Implements a STIX 2.1/TAXII 2.1 threat-intelligence feed consumer and producer in Python, covering TAXII serve |
| `implementing-supply-chain-security-with-in-toto` | 311 | 9.9 | Implements supply chain integrity verification for container builds with the in-toto framework: generating sig |
| `implementing-syslog-centralization-with-rsyslog` | 86 | 2.7 | Configure rsyslog for centralized log collection with TLS encryption, custom templates, and log rotation, gene |
| `implementing-taxii-server-with-opentaxii` | 379 | 13.9 | Deploy and configure a TAXII 2.1 server (Medallion) with Docker, publish and consume STIX 2.1 bundles across c |
| `implementing-threat-intelligence-lifecycle-management` | 395 | 15.0 | Build out a full CTI program around the six-phase threat intelligence lifecycle (direction, collection, proces |
| `implementing-threat-modeling-with-mitre-attack` | 398 | 13.5 | Implements threat modeling using the MITRE ATT&CK framework to map adversary TTPs against organizational asset |
| `implementing-ticketing-system-for-incidents` | 431 | 16.1 | Implements an integrated incident ticketing system connecting SIEM alerts to ServiceNow, Jira, or TheHive for  |
| `implementing-usb-device-control-policy` | 157 | 5.4 | Implements USB device control policies to restrict unauthorized removable media access on endpoints, preventin |
| `implementing-velociraptor-for-ir-collection` | 304 | 9.0 | Deploy and configure Velociraptor for scalable endpoint forensic artifact collection during incident response  |
| `implementing-vulnerability-management-with-greenbone` | 71 | 3.0 | Deploy and operate Greenbone/OpenVAS vulnerability management using the python-gvm library over the Greenbone  |
| `implementing-vulnerability-remediation-sla` | 194 | 7.4 | Design a vulnerability remediation SLA program covering asset tiering, a severity-based SLA matrix, exception  |
| `implementing-vulnerability-sla-breach-alerting` | 308 | 10.0 | Build an automated SLA breach alerting system for vulnerability remediation, including a database schema for S |
| `implementing-web-application-logging-with-modsecurity` | 77 | 2.4 | Configure ModSecurity WAF with the OWASP Core Rule Set (CRS) for web application audit logging, tuning SecRule |
| `implementing-zero-knowledge-proof-for-authentication` | 87 | 3.4 | Implements the Schnorr identification protocol and a simplified Zero-Knowledge Password Proof (ZKPP) over the  |
| `implementing-zero-standing-privilege-with-cyberark` | 249 | 9.3 | Deploy CyberArk Secure Cloud Access (SCA) to eliminate standing privileges in AWS, Azure, and GCP by provision |
| `implementing-zero-trust-dns-with-nextdns` | 366 | 11.0 | Configure NextDNS as an encrypted (DoH/DoT) zero trust DNS resolver that blocks malicious, phishing, and crypt |
| `implementing-zero-trust-for-saas-applications` | 323 | 11.2 | Secures SaaS apps (Microsoft 365, Google Workspace, Salesforce, Slack) via CASB/SSPM deployment, conditional a |
| `implementing-zero-trust-in-cloud` | 320 | 13.0 | Guides zero trust implementation across AWS, Azure, and GCP per NIST SP 800-207 and BeyondCorp principles, cov |
| `implementing-zero-trust-network-access` | 361 | 13.0 | Configures Zero Trust Network Access (ZTNA) in AWS, Azure, and GCP using identity-aware proxies, micro-segment |
| `implementing-zero-trust-network-access-with-zscaler` | 178 | 7.5 | Configures Zero Trust Network Access using Zscaler Private Access (ZPA) to broker identity-based, context-awar |
| `implementing-zero-trust-with-beyondcorp` | 69 | 2.9 | Configures Google BeyondCorp Enterprise Identity-Aware Proxy (IAP) as the access enforcement point for web app |
| `implementing-zero-trust-with-hashicorp-boundary` | 530 | 15.2 | Installs and configures HashiCorp Boundary as a default-deny, identity-aware proxy for infrastructure access,  |
| `integrating-dast-with-owasp-zap-in-pipeline` | 257 | 8.2 | Integrates OWASP ZAP (Zed Attack Proxy) into GitHub Actions and GitLab CI pipelines, covering baseline, full,  |
| `integrating-sast-into-github-actions-pipeline` | 329 | 11.9 | Integrates CodeQL and Semgrep SAST scanning into GitHub Actions, covering scans on pull requests/pushes, rule  |
| `intercepting-mobile-traffic-with-burpsuite` | 203 | 7.0 | Intercepts and analyzes HTTP/HTTPS traffic from mobile applications using Burp Suite proxy to identify insecur |
| `investigating-insider-threat-indicators` | 313 | 11.6 | Investigates insider threat indicators including data exfiltration attempts, unauthorized access patterns, pol |
| `investigating-phishing-email-incident` | 337 | 11.2 | Investigates phishing email incidents from initial user report through header analysis, URL/attachment detonat |
| `investigating-ransomware-attack-artifacts` | 416 | 15.8 | Forensically preserve memory and disk, collect ransom notes and encrypted file samples, and identify the ranso |
| `managing-cloud-identity-with-okta` | 310 | 12.1 | Implement Okta as a centralized cloud identity provider: configure SSO with AWS, Azure, and GCP, deploy phishi |
| `managing-intelligence-lifecycle` | 133 | 6.2 | Manages the end-to-end cyber threat intelligence lifecycle from planning and direction through collection, pro |
| `managing-third-party-vendor-risk` | 143 | 8.5 | Build and run a third-party/vendor risk management (TPRM) program aligned to NIST SP 800-161 C-SCRM: inventory |
| `mapping-attack-paths-with-bloodhound-ce` | 229 | 11.8 | Collect Active Directory data with SharpHound and Entra ID data with AzureHound, ingest into BloodHound Commun |
| `mapping-mitre-attack-techniques` | 166 | 7.1 | Maps observed adversary behaviors, security alerts, and detection rules to MITRE ATT&CK techniques and sub-tec |
| `migrating-to-post-quantum-cryptography` | 214 | 11.8 | Build a cryptographic inventory/CBOM with OpenSSL 3.5+, deploy hybrid post-quantum key exchange (X25519MLKEM76 |
| `modeling-threats-with-opencti` | 271 | 11.1 | Deploy OpenCTI (Filigran) via Docker Compose and use the pycti Python client to model threat actors, intrusion |
| `monitoring-darkweb-sources` | 180 | 8.1 | Monitors dark web forums, marketplaces, paste sites, and ransomware leak sites for mentions of organizational  |
| `monitoring-scada-modbus-traffic-anomalies` | 349 | 24.1 | Monitors Modbus TCP traffic on SCADA and ICS networks to detect anomalous function code usage, unauthorized re |
| `moving-laterally-with-netexec` | 200 | 10.3 | Use NetExec (nxc) to validate credentials, enumerate SMB shares/users/policy, password-spray safely across loc |
| `operating-havoc-c2` | 279 | 10.2 | Deploy a Havoc C2 team server with Yaotl malleable profiles, generate evasive Demon agents using indirect sysc |
| `operating-sliver-c2` | 305 | 11.7 | Stand up a Sliver C2 server and mTLS listeners, generate cross-platform implants and beacons, and run post-exp |
| `operationalizing-misp-threat-feeds` | 221 | 10.3 | Stand up MISP, enable and cache curated threat feeds (CIRCL, abuse.ch, Feodo Tracker), apply warninglists to s |
| `orchestrating-llm-attacks-with-pyrit` | 226 | 10.9 | Build automated multi-turn adversarial attacks against conversational LLM targets using Microsoft PyRIT's RedT |
| `parsing-artifacts-with-eric-zimmerman-tools` | 171 | 8.0 | Parse Windows forensic artifacts—$MFT/$J (MFTECmd), Prefetch (PECmd), registry hives (RECmd), shellbags, and A |
| `performing-access-recertification-with-saviynt` | 292 | 10.9 | Configure and execute access recertification campaigns in Saviynt Enterprise Identity Cloud to validate user e |
| `performing-access-review-and-certification` | 149 | 6.2 | Designs and runs access review and certification campaigns-scoping, reviewer selection, risk-based prioritizat |
| `performing-active-directory-bloodhound-analysis` | 250 | 8.1 | Use BloodHound and SharpHound (or AzureHound) to enumerate Active Directory relationships and graph attack pat |
| `performing-active-directory-compromise-investigation` | 211 | 8.1 | Investigate Active Directory compromise by analyzing authentication logs, replication metadata, Group Policy c |
| `performing-active-directory-forest-trust-attack` | 71 | 2.6 | Enumerate and audit Active Directory forest trust relationships using Impacket for SID filtering analysis, tru |
| `performing-active-directory-penetration-test` | 291 | 9.7 | Conduct a focused Active Directory penetration test using BloodHound, Impacket, Certipy, Rubeus, and NetExec t |
| `performing-active-directory-vulnerability-assessment` | 250 | 8.7 | Assess Active Directory security posture using PingCastle, BloodHound, and Purple Knight to identify misconfig |
| `performing-adversary-in-the-middle-phishing-detection` | 162 | 6.5 | Detect and respond to Adversary-in-the-Middle (AiTM) phishing attacks that use reverse proxy kits like EvilPro |
| `performing-agentless-vulnerability-scanning` | 424 | 14.9 | Configure and execute agentless vulnerability scanning using network protocols, cloud snapshot analysis, and A |
| `performing-ai-driven-osint-correlation` | 404 | 14.3 | Use AI/LLM-based reasoning with Sherlock, theHarvester, and SpiderFoot to correlate OSINT findings—usernames,  |
| `performing-alert-triage-with-elastic-siem` | 258 | 7.9 | Perform systematic alert triage in Elastic Security SIEM—classifying, prioritizing, and investigating alerts u |
| `performing-android-app-static-analysis-with-mobsf` | 178 | 7.2 | Performs automated static analysis of Android applications using Mobile Security Framework (MobSF) to identify |
| `performing-api-fuzzing-with-restler` | 381 | 13.3 | Uses Microsoft RESTler to perform stateful REST API fuzzing: compiles an OpenAPI/Swagger spec into a RESTler g |
| `performing-api-inventory-and-discovery` | 445 | 16.6 | Performs API inventory and discovery to identify all API endpoints in an organization's environment including  |
| `performing-api-rate-limiting-bypass` | 421 | 17.2 | Tests API rate limiting for bypass vulnerabilities using Python (requests/aiohttp) and Burp Suite Turbo Intrud |
| `performing-api-security-testing-with-postman` | 401 | 14.8 | Uses Postman to build structured API security test collections covering the OWASP API Security Top 10—authenti |
| `performing-arp-spoofing-attack-simulation` | 283 | 11.1 | Simulates ARP spoofing/cache-poisoning attacks in authorized lab or pentest environments using arpspoof, Etter |
| `performing-asset-criticality-scoring-for-vulns` | 173 | 6.7 | Build a multi-factor asset criticality scoring model—incorporating data sensitivity, business function depende |
| `performing-authenticated-scan-with-openvas` | 276 | 9.0 | Configure and execute authenticated (credentialed) vulnerability scans using OpenVAS/Greenbone Vulnerability M |
| `performing-authenticated-vulnerability-scan` | 243 | 8.5 | Plan and run authenticated (credentialed) vulnerability scans with scanners such as Nessus, Qualys, OpenVAS, o |
| `performing-automated-malware-analysis-with-cape` | 183 | 6.7 | Deploy and operate the CAPEv2 malware sandbox (a Cuckoo derivative) to run samples in a monitored Windows gues |
| `performing-aws-account-enumeration-with-scout-suite` | 267 | 7.4 | Run the agentless, open-source ScoutSuite tool (via pip install and the `scout` CLI) against an AWS account to |
| `performing-aws-privilege-escalation-assessment` | 292 | 12.1 | Performing authorized privilege escalation assessments in AWS environments to identify IAM misconfigurations t |
| `performing-bandwidth-throttling-attack-simulation` | 336 | 12.2 | Simulate bandwidth throttling and network degradation attacks using tc, iperf3, and Scapy in authorized lab en |
| `performing-binary-exploitation-analysis` | 460 | 14.5 | Analyze ELF binaries for memory-corruption vulnerabilities and build proof-of-concept exploits using pwntools, |
| `performing-blind-ssrf-exploitation` | 257 | 9.7 | Detect and exploit blind Server-Side Request Forgery (SSRF) using out-of-band techniques such as Burp Collabor |
| `performing-bluetooth-security-assessment` | 93 | 4.0 | Assess Bluetooth Low Energy (BLE) device security using Python's bleak asyncio library to discover nearby devi |
| `performing-brand-monitoring-for-impersonation` | 291 | 11.7 | Monitor for brand impersonation attacks across domains, social media, mobile apps, and dark web channels to de |
| `performing-clickjacking-attack-test` | 442 | 13.5 | Testing web applications for clickjacking vulnerabilities by assessing frame embedding controls and crafting p |
| `performing-cloud-asset-inventory-with-cartography` | 257 | 6.6 | Run Cartography to sync AWS, GCP, or Azure resources into a Neo4j graph database, mapping relationships such a |
| `performing-cloud-forensics-investigation` | 350 | 13.4 | Collect and analyze cloud forensic evidence using AWS CLI, Azure CLI, or gcloud to snapshot volumes, capture i |
| `performing-cloud-forensics-with-aws-cloudtrail` | 97 | 3.3 | Investigate AWS account compromise by querying CloudTrail with boto3's LookupEvents or AWS Athena SQL over S3- |
| `performing-cloud-incident-containment-procedures` | 314 | 10.9 | Execute cloud-native incident containment across AWS, Azure, and GCP using platform CLIs to revoke or disable  |
| `performing-cloud-log-forensics-with-athena` | 506 | 14.6 | Uses AWS Athena to query CloudTrail, VPC Flow Logs, S3 access logs, and ALB logs for forensic investigation. C |
| `performing-cloud-native-forensics-with-falco` | 88 | 2.5 | Uses Falco YAML rules for runtime threat detection in containers and Kubernetes, monitoring syscalls for shell |
| `performing-cloud-native-threat-hunting-with-aws-detective` | 176 | 5.8 | Investigate AWS security incidents using Amazon Detective's behavior graphs, built from CloudTrail, VPC Flow L |
| `performing-cloud-penetration-testing-with-pacu` | 308 | 11.1 | Run authorized AWS penetration tests with Pacu, the open-source AWS exploitation framework, to enumerate IAM c |
| `performing-cloud-storage-forensic-acquisition` | 363 | 13.8 | Perform forensic acquisition of cloud storage services including Google Drive, OneDrive, Dropbox, and Box by p |
| `performing-container-escape-detection` | 87 | 2.5 | Audits container and pod configuration for escape-enabling misconfiguration using the Kubernetes Python client |
| `performing-container-image-hardening` | 266 | 8.3 | Harden container images by minimizing attack surface, stripping unnecessary packages, implementing multi-stage |
| `performing-container-security-scanning-with-trivy` | 81 | 3.2 | Runs Trivy across every target type it supports - container images, filesystems, Git repositories, and Kuberne |
| `performing-content-security-policy-bypass` | 252 | 9.0 | Analyze Content-Security-Policy headers and bypass them to achieve cross-site scripting by exploiting unsafe-i |
| `performing-credential-access-with-lazagne` | 262 | 8.6 | Extract stored credentials from compromised endpoints using the LaZagne post-exploitation tool to recover pass |
| `performing-cryptographic-audit-of-application` | 112 | 3.7 | A cryptographic audit systematically reviews an application's use of cryptographic primitives, protocols, and  |
| `performing-csrf-attack-simulation` | 366 | 12.2 | Testing web applications for Cross-Site Request Forgery vulnerabilities by crafting forged requests that explo |
| `performing-cve-prioritization-with-kev-catalog` | 273 | 10.0 | Fetch and parse the CISA Known Exploited Vulnerabilities (KEV) catalog, enrich it with EPSS scores and CVSS me |
| `performing-dark-web-monitoring-for-threats` | 271 | 9.6 | Dark web monitoring involves systematically scanning Tor hidden services, underground forums, paste sites, and |
| `performing-deception-technology-deployment` | 306 | 11.1 | Deploys deception technology including honeypots, honeytokens, and decoy systems to detect attackers who have  |
| `performing-directory-traversal-testing` | 332 | 11.2 | Test web applications for path traversal and Local/Remote File Inclusion vulnerabilities by manipulating file  |
| `performing-disk-forensics-investigation` | 273 | 10.5 | Conduct disk forensics investigations using forensic imaging, file system analysis, and timeline reconstructio |
| `performing-dmarc-policy-enforcement-rollout` | 140 | 6.1 | Execute a phased DMARC rollout by inventorying sending sources, configuring SPF/DKIM alignment, and progressin |
| `performing-dns-enumeration-and-zone-transfer` | 276 | 10.5 | Enumerates DNS records, attempts zone transfers, brute-forces subdomains, and maps DNS infrastructure during a |
| `performing-dns-tunneling-detection` | 93 | 2.5 | Detects DNS tunneling by computing Shannon entropy of DNS query names, analyzing query length distributions, i |
| `performing-docker-bench-security-assessment` | 156 | 4.9 | Runs Docker Bench for Security, the open-source CIS Docker Benchmark audit script, across host configuration,  |
| `performing-dynamic-analysis-of-android-app` | 254 | 8.5 | Performs runtime dynamic analysis of Android applications using Frida, Objection, and Android Debug Bridge to  |
| `performing-dynamic-analysis-with-any-run` | 284 | 11.1 | Perform interactive dynamic malware analysis using the ANY.RUN cloud sandbox to detonate samples, observe real |
| `performing-endpoint-forensics-investigation` | 251 | 8.0 | Performs digital forensics investigation on compromised endpoints including memory acquisition, disk imaging,  |
| `performing-endpoint-vulnerability-remediation` | 243 | 8.5 | Performs vulnerability remediation on endpoints by prioritizing CVEs based on risk scoring, deploying patches, |
| `performing-entitlement-review-with-sailpoint-iiq` | 492 | 18.5 | Runs entitlement review and access certification campaigns in SailPoint IdentityIQ, covering manager certifica |
| `performing-external-network-penetration-test` | 359 | 10.3 | Conduct a comprehensive external network penetration test to identify vulnerabilities in internet-facing infra |
| `performing-false-positive-reduction-in-siem` | 240 | 7.3 | Reduces SIEM false positives through systematic rule tuning, threshold adjustment, correlation logic refinemen |
| `performing-file-carving-with-foremost` | 336 | 12.3 | Recovers files from disk images and unallocated space using Foremost's header-footer signature carving, extrac |
| `performing-firmware-extraction-with-binwalk` | 295 | 10.9 | Performs firmware image extraction and analysis using binwalk to identify embedded filesystems, compressed arc |
| `performing-firmware-malware-analysis` | 318 | 11.6 | Analyzes firmware images for embedded malware, backdoors, and unauthorized modifications in routers, IoT devic |
| `performing-fuzzing-with-aflplusplus` | 88 | 2.5 | Performs coverage-guided fuzzing of compiled binaries with AFL++, instrumenting targets via afl-cc/afl-clang-f |
| `performing-gcp-penetration-testing-with-gcpbucketbrute` | 78 | 2.8 | Performs authorized GCP security testing using GCPBucketBrute to enumerate publicly accessible storage buckets |
| `performing-gcp-security-assessment-with-forseti` | 301 | 11.0 | Performing comprehensive security assessments of Google Cloud Platform environments using Forseti Security, Se |
| `performing-graphql-depth-limit-attack` | 425 | 12.7 | Execute and test GraphQL depth limit attacks using deeply nested recursive queries to identify denial-of-servi |
| `performing-graphql-introspection-attack` | 527 | 19.2 | Performs GraphQL introspection attacks that extract the full API schema (types, queries, mutations, subscripti |
| `performing-graphql-security-assessment` | 342 | 13.8 | Assessing GraphQL API endpoints for introspection leaks, injection attacks, authorization flaws, and denial-of |
| `performing-hardware-security-module-integration` | 76 | 2.4 | Integrates Hardware Security Modules (HSMs) via the PKCS#11 interface using python-pkcs11, performing key gene |
| `performing-hash-cracking-with-hashcat` | 97 | 3.5 | Cracks password hashes with Hashcat, covering hash-type identification, dictionary/brute-force/rule-based atta |
| `performing-http-parameter-pollution-attack` | 212 | 7.8 | Executes HTTP Parameter Pollution attacks that inject duplicate request parameters to bypass input validation, |
| `performing-ics-asset-discovery-with-claroty` | 525 | 19.1 | Performs ICS/OT asset discovery with Claroty xDome, combining passive monitoring and Claroty Edge active queri |
| `performing-indicator-lifecycle-management` | 149 | 5.7 | Tracks IOCs through discovery, enrichment/validation (VirusTotal, Shodan, passive DNS), deployment to SIEM/IDS |
| `performing-initial-access-with-evilginx3` | 225 | 7.6 | Perform authorized initial access using EvilGinx3 adversary-in-the-middle phishing framework to capture sessio |
| `performing-insider-threat-investigation` | 261 | 11.3 | Investigates insider threat incidents involving employees, contractors, or trusted partners who misuse authori |
| `performing-ioc-enrichment-automation` | 434 | 16.4 | Automates Indicator of Compromise (IOC) enrichment by orchestrating lookups across VirusTotal, AbuseIPDB, Shod |
| `performing-ios-app-security-assessment` | 290 | 11.6 | Performs comprehensive iOS application security assessments using Frida for dynamic instrumentation, Objection |
| `performing-iot-security-assessment` | 203 | 12.4 | Performs comprehensive security assessments of IoT devices and their ecosystems by testing hardware interfaces |
| `performing-ip-reputation-analysis-with-shodan` | 306 | 11.5 | Analyze IP address reputation using the Shodan API to identify open ports, running services, known vulnerabili |
| `performing-jwt-none-algorithm-attack` | 349 | 12.1 | Execute and test the JWT none algorithm attack, crafting tokens with the alg header set to none using PyJWT an |
| `performing-kerberoasting-attack` | 120 | 4.4 | Perform Kerberoasting, a post-exploitation technique that enumerates Active Directory service accounts with Se |
| `performing-kubernetes-cis-benchmark-with-kube-bench` | 244 | 6.7 | Turns kube-bench output into a finished CIS Kubernetes Benchmark audit: interpreting PASS/FAIL/WARN per contro |
| `performing-kubernetes-etcd-security-assessment` | 231 | 7.3 | Assesses the security posture of the etcd cluster backing Kubernetes: encryption at rest, TLS peer and client  |
| `performing-kubernetes-penetration-testing` | 287 | 8.6 | Evaluates Kubernetes cluster security by actively simulating attacker techniques against the API server, kubel |
| `performing-lateral-movement-detection` | 321 | 12.3 | Detects lateral movement techniques including Pass-the-Hash, PsExec, WMI execution, RDP pivoting, and SMB-base |
| `performing-lateral-movement-with-wmiexec` | 214 | 8.6 | Perform lateral movement across Windows networks using WMI-based remote execution techniques including Impacke |
| `performing-linux-log-forensics-investigation` | 303 | 10.5 | Perform forensic investigation of Linux system logs including syslog, auth.log, systemd journal (via journalct |
| `performing-log-analysis-for-forensic-investigation` | 326 | 12.3 | Collect, parse, and correlate system, application, and security logs to reconstruct events and establish timel |
| `performing-log-source-onboarding-in-siem` | 302 | 9.5 | Perform structured log source onboarding into SIEM platforms (Splunk, Elastic, Sentinel, QRadar, or similar) b |
| `performing-malware-hash-enrichment-with-virustotal` | 352 | 14.1 | Enrich malware file hashes (MD5, SHA-1, SHA-256) using the VirusTotal API v3 to retrieve multi-engine detectio |
| `performing-malware-ioc-extraction` | 377 | 12.5 | Malware IOC extraction is the process of analyzing malicious software to identify actionable indicators of com |
| `performing-malware-persistence-investigation` | 476 | 18.2 | Systematically investigate all persistence mechanisms on Windows and Linux systems to identify how malware sur |
| `performing-malware-triage-with-yara` | 382 | 12.3 | Performs rapid malware triage and classification using YARA rules that match file patterns, strings, byte sequ |
| `performing-memory-forensics-with-volatility3` | 306 | 11.7 | Analyze volatile memory (RAM) dumps using the Volatility 3 framework to extract running processes, network con |
| `performing-memory-forensics-with-volatility3-plugins` | 244 | 8.3 | Analyze memory dumps using Volatility3 plugins to detect injected code, rootkits, credential theft, and malwar |
| `performing-mobile-app-certificate-pinning-bypass` | 244 | 8.5 | Bypasses SSL/TLS certificate pinning implementations in Android and iOS applications to enable traffic interce |
| `performing-mobile-device-forensics-with-cellebrite` | 349 | 12.2 | Acquire and analyze mobile device data using Cellebrite UFED Touch/4PC, UFED Physical Analyzer, and open-sourc |
| `performing-network-forensics-with-wireshark` | 318 | 11.7 | Capture and analyze network traffic using Wireshark and tshark to reconstruct network events from PCAP/PCAPNG  |
| `performing-network-packet-capture-analysis` | 265 | 8.8 | Perform forensic analysis of network packet captures (PCAP/PCAPNG) using Wireshark, tshark, and tcpdump to rec |
| `performing-network-traffic-analysis-with-tshark` | 65 | 2.4 | Automate network traffic analysis using tshark (Wireshark CLI) and pyshark to compute protocol distribution st |
| `performing-network-traffic-analysis-with-zeek` | 423 | 12.4 | Deploy Zeek (formerly Bro) as a passive network security monitor to generate structured logs of protocol metad |
| `performing-nist-csf-maturity-assessment` | 142 | 5.8 | Conduct a NIST Cybersecurity Framework (CSF) 2.0 maturity assessment across the six core Functions (Govern, Id |
| `performing-oauth-scope-minimization-review` | 655 | 24.3 | Performs OAuth 2.0 scope minimization review to identify over-permissioned third-party application integration |
| `performing-oil-gas-cybersecurity-assessment` | 370 | 15.6 | Conduct cybersecurity assessments of upstream, midstream, and downstream oil and gas operations, covering pipe |
| `performing-open-source-intelligence-gathering` | 143 | 5.7 | Open Source Intelligence (OSINT) gathering is the first active phase of a red team engagement, where operators |
| `performing-osint-with-spiderfoot` | 63 | 2.4 | Automate OSINT collection with the SpiderFoot REST API and CLI (sf.py/spiderfoot-cli) across 200+ modules, sel |
| `performing-ot-network-security-assessment` | 602 | 23.8 | This skill covers conducting comprehensive security assessments of Operational Technology (OT) networks includ |
| `performing-ot-vulnerability-assessment-with-claroty` | 316 | 12.2 | Perform OT vulnerability assessments using the Claroty xDome platform for asset discovery, risk scoring, and v |
| `performing-ot-vulnerability-scanning-safely` | 299 | 11.2 | Perform vulnerability scanning in OT/ICS environments safely using passive monitoring, native protocol queries |
| `performing-packet-injection-attack` | 335 | 12.1 | Crafts and injects custom network packets using Scapy, hping3, and Nemesis during authorized security assessme |
| `performing-paste-site-monitoring-for-credentials` | 380 | 14.6 | Monitor paste sites like Pastebin and GitHub Gists for leaked credentials, API keys, and sensitive data dumps  |
| `performing-phishing-simulation-with-gophish` | 150 | 5.1 | Deploy and run authorized phishing awareness campaigns with GoPhish, covering admin panel setup, SMTP sending  |
| `performing-physical-intrusion-assessment` | 223 | 8.0 | Conduct authorized physical penetration testing against facilities, server rooms, and restricted areas using t |
| `performing-plc-firmware-security-analysis` | 506 | 19.1 | This skill covers analyzing Programmable Logic Controller (PLC) firmware for security vulnerabilities includin |
| `performing-post-quantum-cryptography-migration` | 346 | 12.4 | Assesses organizational readiness for post-quantum cryptography migration per NIST FIPS 203/204/205 standards. |
| `performing-power-grid-cybersecurity-assessment` | 310 | 11.8 | Conduct cybersecurity assessments of power grid infrastructure spanning generation, transmission substations,  |
| `performing-privacy-impact-assessment` | 289 | 10.3 | Automates the Privacy Impact Assessment (PIA) workflow including data flow mapping, privacy risk scoring matri |
| `performing-privilege-escalation-assessment` | 220 | 12.4 | Performs privilege escalation assessments on compromised Linux and Windows systems to identify paths from low- |
| `performing-privilege-escalation-on-linux` | 123 | 4.1 | Guides manual enumeration and automated tooling to escalate from a low-privilege Linux user to root by exploit |
| `performing-privileged-account-access-review` | 181 | 7.8 | Conducts systematic reviews of privileged accounts to validate access rights, identify excessive or stale perm |
| `performing-privileged-account-discovery` | 74 | 2.6 | Discovers and inventories privileged accounts across enterprise infrastructure, including domain admins, local |
| `performing-purple-team-atomic-testing` | 1011 | 39.7 | Executes Atomic Red Team tests mapped to MITRE ATT&CK via Invoke-AtomicRedTeam PowerShell, generates ATT&CK Na |
| `performing-purple-team-exercise` | 317 | 13.0 | Performs purple team exercises by coordinating red team adversary emulation with blue team detection validatio |
| `performing-ransomware-response` | 261 | 11.3 | Executes a structured ransomware incident response from detection through containment, forensic analysis, decr |
| `performing-ransomware-tabletop-exercise` | 265 | 11.5 | Plans and facilitates tabletop exercises simulating ransomware incidents, using realistic scenarios based on t |
| `performing-red-team-phishing-with-gophish` | 104 | 3.1 | Automates GoPhish phishing simulation campaigns using the Python gophish library, creating email templates wit |
| `performing-red-team-with-covenant` | 71 | 2.4 | Conducts red team operations using the Covenant C2 framework for authorized adversary simulation, covering lis |
| `performing-s7comm-protocol-security-analysis` | 440 | 16.6 | Perform security analysis of Siemens S7comm and S7CommPlus protocols used by SIMATIC S7 PLCs to identify vulne |
| `performing-sca-dependency-scanning-with-snyk` | 267 | 8.6 | This skill covers implementing Software Composition Analysis (SCA) using Snyk to detect vulnerable open-source |
| `performing-scada-hmi-security-assessment` | 322 | 11.6 | Perform security assessments of SCADA Human-Machine Interface (HMI) systems to identify vulnerabilities in web |
| `performing-second-order-sql-injection` | 236 | 8.9 | Detect and exploit second-order SQL injection vulnerabilities where malicious input is stored in a database an |
| `performing-security-headers-audit` | 326 | 12.6 | Auditing HTTP security headers including CSP, HSTS, X-Frame-Options, and cookie attributes to identify missing |
| `performing-serverless-function-security-review` | 307 | 12.2 | Performing security reviews of serverless functions across AWS Lambda, Azure Functions, and GCP Cloud Function |
| `performing-service-account-audit` | 133 | 5.3 | Audit service accounts across enterprise infrastructure to identify orphaned, over-privileged, and non-complia |
| `performing-service-account-credential-rotation` | 306 | 10.4 | Automates credential rotation for service accounts across Active Directory, cloud platforms, and application d |
| `performing-soap-web-service-security-testing` | 462 | 16.3 | Performs security testing of SOAP web services by analyzing WSDL definitions and testing for XML injection, XX |
| `performing-soc-tabletop-exercise` | 409 | 16.6 | Performs tabletop exercises for SOC teams simulating security incidents through discussion-based scenarios to  |
| `performing-soc2-type2-audit-preparation` | 309 | 10.4 | Automates SOC 2 Type II audit preparation including gap assessment against AICPA Trust Services Criteria (CC1- |
| `performing-sqlite-database-forensics` | 374 | 14.0 | Performs forensic analysis of SQLite databases by examining B-tree page structures, recovering deleted records |
| `performing-ssl-certificate-lifecycle-management` | 98 | 3.4 | Automates the full SSL/TLS certificate lifecycle, including generating Certificate Signing Requests, issuing,  |
| `performing-ssl-stripping-attack` | 271 | 10.6 | Simulates SSL stripping / HTTPS downgrade attacks using sslstrip, Bettercap, and mitmproxy in authorized lab e |
| `performing-ssl-tls-inspection-configuration` | 297 | 11.6 | Configure SSL/TLS break-and-inspect on next-generation firewalls and forward proxies to decrypt, inspect, and  |
| `performing-ssl-tls-security-assessment` | 72 | 2.3 | Assess SSL/TLS server configurations using the sslyze Python scanning library to evaluate supported protocol v |
| `performing-ssrf-vulnerability-exploitation` | 73 | 2.3 | Tests web application URL parameters for Server-Side Request Forgery by probing cloud metadata endpoints (AWS/ |
| `performing-static-malware-analysis-with-pe-studio` | 314 | 12.9 | Performs static analysis of Windows PE malware samples using PEStudio to examine file headers, imports, string |
| `performing-steganography-detection` | 356 | 12.2 | Detects and extracts hidden data embedded in images, audio, and other media files using steganalysis tools suc |
| `performing-subdomain-enumeration-with-subfinder` | 200 | 6.8 | Enumerate subdomains of target domains using ProjectDiscovery's Subfinder passive reconnaissance tool to map t |
| `performing-supply-chain-attack-simulation` | 70 | 2.8 | Simulates and detects software supply chain attacks: typosquatting detection via Levenshtein distance against  |
| `performing-thick-client-application-penetration-test` | 272 | 8.2 | Conduct a thick client application penetration test to identify insecure local storage, hardcoded credentials, |
| `performing-threat-emulation-with-atomic-red-team` | 99 | 2.5 | Executes Atomic Red Team tests for MITRE ATT&CK technique validation using the atomic-operator Python framewor |
| `performing-threat-hunting-with-elastic-siem` | 294 | 9.7 | Performs proactive threat hunting in Elastic Security SIEM using KQL/EQL queries, detection rules, and Timelin |
| `performing-threat-hunting-with-yara-rules` | 434 | 13.5 | Use YARA pattern-matching rules to hunt for malware, suspicious files, and indicators of compromise across fil |
| `performing-threat-intelligence-sharing-with-misp` | 73 | 3.0 | Uses PyMISP (the official MISP REST API library) to create events with structured IOCs (IPs, domains, hashes,  |
| `performing-threat-landscape-assessment-for-sector` | 306 | 12.5 | Conducts a sector-specific threat landscape assessment (financial, healthcare, energy, government, etc.) by pr |
| `performing-threat-modeling-with-owasp-threat-dragon` | 218 | 8.3 | Uses OWASP Threat Dragon (web or desktop) to build data flow diagrams, identify threats with STRIDE, LINDDUN,  |
| `performing-timeline-reconstruction-with-plaso` | 336 | 11.8 | Builds comprehensive forensic super-timelines using Plaso (log2timeline and psort) to correlate events across  |
| `performing-user-behavior-analytics` | 261 | 10.2 | Performs User and Entity Behavior Analytics (UEBA) to detect anomalous user activities including impossible tr |
| `performing-vlan-hopping-attack` | 336 | 12.5 | Simulates VLAN hopping attacks using switch spoofing and 802.1Q double tagging techniques in authorized lab en |
| `performing-vulnerability-scanning-with-nessus` | 178 | 11.0 | Performs authenticated and unauthenticated vulnerability scanning using Tenable Nessus to identify known vulne |
| `performing-web-application-firewall-bypass` | 266 | 9.5 | Bypasses Web Application Firewall protections using encoding tricks, HTTP method manipulation, parameter pollu |
| `performing-web-application-penetration-test` | 209 | 13.7 | Performs systematic security testing of web applications following the OWASP Web Security Testing Guide (WSTG) |
| `performing-web-application-scanning-with-nikto` | 248 | 7.9 | Runs Nikto, an open-source web server and web application scanner, to test over 7,000 potentially dangerous fi |
| `performing-web-application-vulnerability-triage` | 251 | 8.6 | Triages web application vulnerability findings from DAST/SAST scanners such as Burp Suite and ZAP, using the O |
| `performing-web-cache-deception-attack` | 229 | 8.8 | Executes web cache deception attacks by exploiting path normalization discrepancies between CDN/reverse-proxy  |
| `performing-web-cache-poisoning-attack` | 328 | 12.2 | Exploiting web cache mechanisms to serve malicious content to other users by poisoning cached responses throug |
| `performing-wifi-password-cracking-with-aircrack` | 284 | 10.9 | Captures WPA/WPA2 handshakes and performs offline password cracking using aircrack-ng, hashcat, and dictionary |
| `performing-windows-artifact-analysis-with-eric-zimmerman-tools` | 296 | 11.8 | Performs comprehensive Windows forensic artifact analysis using Eric Zimmerman's open-source EZ Tools suite (K |
| `performing-wireless-network-penetration-test` | 266 | 7.0 | Execute a wireless network penetration test to assess WiFi security by capturing handshakes, cracking WPA2/WPA |
| `performing-wireless-security-assessment-with-kismet` | 398 | 13.1 | Conduct wireless network security assessments using Kismet to detect rogue access points, hidden SSIDs, weak e |
| `performing-yara-rule-development-for-detection` | 346 | 11.6 | Develops precise YARA and YARA-X rules for malware detection by identifying unique strings, byte sequences, PE |
| `post-exploiting-microsoft-graph-with-graphrunner` | 212 | 10.1 | Runs GraphRunner, a PowerShell post-exploitation toolset built on the Microsoft Graph API, to perform tenant r |
| `prioritizing-vulnerabilities-with-cvss-scoring` | 194 | 7.4 | The Common Vulnerability Scoring System (CVSS) is the industry standard framework maintained by FIRST (Forum o |
| `processing-stix-taxii-feeds` | 169 | 6.7 | Processes STIX 2.1 threat intelligence bundles delivered via TAXII 2.1 servers, normalizing objects into platf |
| `profiling-threat-actor-groups` | 144 | 7.1 | Develops comprehensive threat actor profiles for APT groups, criminal organizations, and hacktivist collective |
| `recovering-deleted-files-with-photorec` | 253 | 9.1 | Recovers deleted files from disk images and storage media using PhotoRec's file signature-based carving engine |
| `recovering-from-ransomware-attack` | 341 | 12.5 | Executes structured ransomware incident recovery following NIST/CISA frameworks: environment isolation, forens |
| `red-teaming-llms-with-garak` | 227 | 11.2 | Runs NVIDIA garak probe suites (jailbreak, prompt injection, data leakage, toxicity, and more) against an LLM  |
| `relaying-ntlm-for-adcs-esc8` | 199 | 9.2 | Uses Impacket's ntlmrelayx.py with a coercion tool (PetitPotam, Coercer, printerbug) to relay NTLM authenticat |
| `remediating-s3-bucket-misconfiguration` | 321 | 11.7 | Provides step-by-step procedures for remediating Amazon S3 bucket misconfigurations that expose sensitive data |
| `reverse-engineering-android-malware-with-jadx` | 362 | 12.5 | Reverse engineers malicious Android APK files using the JADX decompiler to read Java/Kotlin source, inspect ma |
| `reverse-engineering-dotnet-malware-with-dnspy` | 355 | 13.0 | Reverse engineers .NET malware samples using the dnSpy decompiler and debugger to read C#/VB.NET source, deobf |
| `reverse-engineering-ios-app-with-frida` | 260 | 9.1 | Reverse engineers iOS applications using Frida dynamic instrumentation to understand internal logic, extract e |
| `reverse-engineering-malware-with-ghidra` | 298 | 12.0 | Reverse engineers malware binaries using NSA's Ghidra disassembler and decompiler to study internal logic, cry |
| `reverse-engineering-ransomware-encryption-routine` | 314 | 10.8 | Reverse engineer ransomware encryption routines to identify cryptographic algorithms, key generation flaws, an |
| `reverse-engineering-rust-malware` | 189 | 6.8 | Reverse engineers Rust-compiled malware using IDA Pro and Ghidra, covering techniques for non-null-terminated  |
| `scanning-container-images-with-grype` | 241 | 5.8 | Scans container images, filesystems, and SBOMs for known CVEs with Anchore Grype, matching Syft-generated SBOM |
| `scanning-containers-with-trivy-in-cicd` | 332 | 10.5 | Integrates Aqua Security's Trivy scanner into CI/CD pipelines to detect OS package and application dependency  |
| `scanning-docker-images-with-trivy` | 275 | 7.4 | Scans a Docker image with Trivy for vulnerabilities in OS packages and language dependencies, misconfiguration |
| `scanning-iac-and-images-with-trivy` | 265 | 10.3 | Scans container images, Infrastructure-as-Code (Terraform, CloudFormation, Kubernetes manifests, Dockerfile, H |
| `scanning-infrastructure-with-nessus` | 181 | 6.7 | Tenable Nessus is the industry-leading vulnerability scanner used to identify security weaknesses across netwo |
| `scanning-kubernetes-manifests-with-kubesec` | 313 | 9.0 | Scores Kubernetes resource manifests with Kubesec to flag misconfiguration and privilege-escalation risk befor |
| `scanning-network-with-nmap-advanced` | 216 | 9.0 | Performs advanced network recon using Nmap's Scripting Engine (NSE), timing controls, firewall/IDS evasion, an |
| `securing-agentic-ai-tool-invocation` | 270 | 11.6 | Implements defense-in-depth controls at an AI agent's tool-invocation boundary using tool allowlisting, least- |
| `securing-api-gateway-with-aws-waf` | 459 | 14.4 | Secures AWS API Gateway endpoints with AWS WAF by configuring managed rule groups for OWASP Top 10 protection, |
| `securing-aws-iam-permissions` | 350 | 12.9 | Hardens AWS IAM configurations to enforce least-privilege access, covering IAM policy scoping, permission boun |
| `securing-aws-lambda-execution-roles` | 382 | 13.0 | Hardens AWS Lambda execution roles by writing least-privilege IAM policies, applying permission boundaries, re |
| `securing-azure-with-microsoft-defender` | 277 | 11.7 | Deploys and configures Microsoft Defender for Cloud as a CNAPP for Azure, multi-cloud, and hybrid environments |
| `securing-container-registry-images` | 312 | 11.0 | Secures container registry images (ECR, ACR, GCR, Docker Hub) by scanning with Trivy and Grype, signing with C |
| `securing-container-registry-with-harbor` | 252 | 7.3 | Configures the security features of the Harbor open-source container registry - integrated Trivy scanning, Cos |
| `securing-github-actions-workflows` | 264 | 8.5 | Hardens GitHub Actions workflows against supply chain attacks, credential theft, and privilege escalation: pin |
| `securing-helm-chart-deployments` | 301 | 7.3 | Secures Helm chart deployments by verifying chart signatures and provenance, rendering and linting templates f |
| `securing-historian-server-in-ot-environment` | 391 | 14.8 | Audits and hardens process historian servers (OSIsoft PI, Honeywell PHD, GE Proficy, AVEVA Historian) in OT en |
| `securing-kubernetes-on-cloud` | 388 | 12.7 | Hardens managed Kubernetes clusters on EKS, AKS, and GKE by implementing Pod Security Standards, network polic |
| `securing-remote-access-to-ot-environment` | 392 | 14.1 | Designs and configures secure remote access to OT/ICS environments for operators, engineers, and vendors: jump |
| `securing-serverless-functions` | 330 | 12.1 | Hardens serverless compute platforms (AWS Lambda, Azure Functions, Google Cloud Functions): least-privilege IA |
| `testing-android-intents-for-vulnerabilities` | 195 | 6.9 | Tests Android inter-process communication (IPC) through intents for vulnerabilities including intent injection |
| `testing-api-authentication-weaknesses` | 457 | 17.1 | Tests API authentication mechanisms for weaknesses including broken token validation, missing authentication o |
| `testing-api-for-broken-object-level-authorization` | 393 | 15.8 | Tests REST and GraphQL APIs for Broken Object Level Authorization (BOLA/IDOR, OWASP API1:2023) by intercepting |
| `testing-api-for-mass-assignment-vulnerability` | 360 | 15.5 | Tests APIs for mass assignment (auto-binding), OWASP API3:2023, by identifying writable endpoints, adding undo |
| `testing-api-security-with-owasp-top-10` | 356 | 12.7 | Systematically assesses REST, GraphQL, and gRPC API endpoints against the OWASP API Security Top 10 (2023) usi |
| `testing-cors-misconfiguration` | 350 | 11.8 | Identifying and exploiting Cross-Origin Resource Sharing misconfigurations that allow unauthorized cross-domai |
| `testing-for-broken-access-control` | 370 | 13.0 | Systematically tests web applications and APIs for broken access control (OWASP A01:2021), including privilege |
| `testing-for-business-logic-vulnerabilities` | 364 | 12.9 | Manually identifies flaws in application business logic - price manipulation, multi-step workflow bypass, and  |
| `testing-for-email-header-injection` | 235 | 8.4 | Tests web application email functionality (contact forms, password reset, newsletter subscriptions) for CRLF/S |
| `testing-for-host-header-injection` | 237 | 8.6 | Test web applications for HTTP Host header injection vulnerabilities to identify password reset poisoning, web |
| `testing-for-json-web-token-vulnerabilities` | 247 | 8.8 | Tests JWT implementations for algorithm confusion, "none" algorithm bypass, kid/jku parameter injection, and w |
| `testing-for-open-redirect-vulnerabilities` | 214 | 7.9 | Identifies and exploits open redirect vulnerabilities by analyzing URL redirection parameters (next, url, redi |
| `testing-for-sensitive-data-exposure` | 378 | 14.0 | Identifying sensitive data exposure vulnerabilities including API key leakage, PII in responses, insecure stor |
| `testing-for-system-prompt-leakage` | 216 | 9.2 | Extracts LLM system prompts using direct requests, jailbreak/instruction-override framing, translation/encodin |
| `testing-for-xml-injection-vulnerabilities` | 228 | 7.6 | Test web applications for XML injection vulnerabilities including XXE, XPath injection, and XML entity attacks |
| `testing-for-xss-vulnerabilities` | 202 | 11.3 | Tests web applications for reflected, stored, and DOM-based Cross-Site Scripting by injecting JavaScript paylo |
| `testing-for-xss-vulnerabilities-with-burpsuite` | 324 | 10.9 | Identifying and validating cross-site scripting vulnerabilities using Burp Suite's scanner, intruder, and repe |
| `testing-for-xxe-injection-vulnerabilities` | 359 | 11.9 | Discovering and exploiting XML External Entity injection vulnerabilities to read server files, perform SSRF, a |
| `testing-jwt-token-security` | 355 | 11.2 | Assessing JSON Web Token implementations for cryptographic weaknesses, algorithm confusion attacks, and author |
| `testing-mobile-api-authentication` | 204 | 7.0 | Tests authentication and authorization mechanisms in mobile application APIs to identify broken authentication |
| `testing-oauth2-implementation-flaws` | 406 | 16.9 | Tests OAuth 2.0 and OpenID Connect implementations for authorization code interception, redirect URI manipulat |
| `testing-prompt-injection-in-rag-pipelines` | 275 | 12.7 | Probes Retrieval-Augmented Generation pipelines for indirect prompt injection via poisoned retrieved documents |
| `testing-ransomware-recovery-procedures` | 205 | 7.6 | Tests and validates ransomware recovery procedures - backup restore operations (e.g. with Restic), RTO/RPO tar |
| `testing-websocket-api-security` | 447 | 18.0 | Tests WebSocket API implementations for missing upgrade-handshake authentication, Cross-Site WebSocket Hijacki |
| `tracking-threat-actor-infrastructure` | 340 | 11.3 | Discovers and maps adversary-controlled infrastructure (C2 servers, phishing domains, exploit-kit hosts, bulle |
| `triaging-security-alerts-in-splunk` | 225 | 8.3 | Triages security alerts in Splunk Enterprise Security by classifying severity, investigating notable events, c |
| `triaging-security-incident` | 229 | 9.2 | Performs initial triage of security incidents using the NIST SP 800-61r3 and SANS PICERL frameworks, classifyi |
| `triaging-security-incident-with-ir-playbook` | 234 | 8.6 | Classifies and prioritizes security incidents using structured IR playbooks and SIEM/case-management queries ( |
| `triaging-vulnerabilities-with-ssvc-framework` | 218 | 7.6 | Triages and prioritizes vulnerabilities with CISA's Stakeholder-Specific Vulnerability Categorization (SSVC) d |
| `triaging-windows-with-kape` | 193 | 9.0 | Runs KAPE (Kroll Artifact Parser and Extractor) to collect targeted forensic artifacts (registry hives, $MFT,  |
| `validating-backup-integrity-for-recovery` | 213 | 7.6 | Validates backup integrity through cryptographic hash verification, automated restore testing, corruption dete |
| `validating-tpm-measured-boot-attestation` | 184 | 9.6 | Verifies TPM 2.0 measured-boot integrity and remote attestation with tpm2-tools -- reading PCRs (tpm2_pcrread) |
| `verifying-build-provenance-with-slsa-sigstore` | 197 | 10.4 | Verifies artifact signatures and SLSA provenance using Sigstore's cosign (verify, verify-attestation, verify-b |
