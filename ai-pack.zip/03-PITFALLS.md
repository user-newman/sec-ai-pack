# 03 · PITFALLS（实测踩出来的坑）

> 每条都来自本项目对真实 APT29 / APT10 / APT3 数据的分析，附具体数字，不是经验之谈。

## 网络流量

### P1 · C2 不在 443，只过滤 443 会漏掉整条 C2
- APT29 day1：C2 在 **8443**，`conn.log` 中 `10.0.1.6 -> 192.168.0.4:8443` **376 次**。
- 同一份 pcap 里按包数排：**8443 = 2666 包**，445 = 967 包。只盯 443 会得出"没有外联"的错误结论。
- 做法：TLS 解析**不要绑定端口**，凡是 TCP 载荷首字节 `0x16` 就尝试解 ClientHello。

### P2 · SNI 写成 IP 字面量，是最强的 C2 信号之一
- day1 的 `ssl.log`：`server_name = "192.168.0.4"`，**376 次**。
- 正常 CDN/网站不会用 IP 当 SNI；出现 `SNI == IP` 基本可判 C2。
- 反过来，day2 的 C2 `192.168.0.4:443` **312 次 `server_name` 为空**——"无 SNI 的 TLS"同样是信号。

### P3 · 上传成功的状态码可能是 204，不是 200
- 外泄：`PUT http://192.168.0.4/webdav/OfficeSupplies.7z`，`request_body_len = 1082089`，**status 204**。
- 只写"HTTP 200 才算成功"会把这 1.03 MB 外泄判成失败。

### P4 · 横向移动的源端口是动态端口，不是 445
- `10.0.1.4 -> 10.0.1.6:55121` **36 次**，`-> 10.0.1.6:445` 30 次。
- 只按 `dport == 445` 过滤会漏掉一半 SMB 会话。按 `(src, dst)` 看更稳。

### P5 · Zeek 日志有两种格式，别用同一套解析
- `combined_zeek.log`：`日志路径 \t ts \t uid \t {json}` —— 前面有 3 个 TSV 字段。
- `individual_zeek_logs/*.log`：纯 JSON 行。
- 直接 `line.split("\t")[1]` 取时间会把 combined 格式切坏。

## 主机日志

### P6 · Sysmon 的 Message 是文本，不是 XML
- 字段形如 `Process accessed:\r\nRuleName: -\r\nSourceImage: ...`。
- 按 XML 解析会全部失败；要按 `Key: Value` 逐行切。

### P7 · 注册表事件会淹没进程事件，必须裁剪
- day1 全量 **196,081** 事件中：注册表创建 **61,152**、进程访问 39,286、映像加载 20,259。
- 进程创建只有 **450** 条。不按 EventID 裁剪，噪声比 400:1。

### P8 · 初始载荷的扩展名是伪装的
- 载荷：`C:\ProgramData\victim\cod.3aka3.scr` —— `.scr` 是屏保，实际是可执行文件。
- 进程链：`cod.3aka3.scr` → `cmd.exe` → `powershell.exe`；另一条 `control.exe` → `powershell.exe`（T1218.002 控制面板项执行）。

### P9 · PowerShell 参数本身就说明了意图
- `-noni -noexit -ep bypass -window hidden -c "sal a New-Object;Add-Type -AssemblyName 'System.Drawing'; $g=a System.Drawing.Bitmap(...)"`
- `System.Drawing.Bitmap` + `-window hidden` = **屏幕截图**（T1113），不是正常运维。
- 横向工具：`psexec64.exe`；云侦察：`dsregcmd.exe`（Azure AD 设备注册查询）。

### P10 · 父子进程关系错位 = 进程镂空
- `svchost.exe` 的父进程是 `C:\Users\IEUser\Desktop\info.rar\jjs.exe`，而正常必须由 `services.exe` 派生。
- 命令行是裸 `C:\Windows\system32\svchost.exe`，缺 `-k <服务组>`。
- `CreateRemoteThread` 的 `StartAddress=0x00060000` 不在任何已加载模块内 → 注入/镂空。

### P11 · 持久化的证据在注册表事件里，不在进程事件里
- `services.exe` 写 `HKLM\System\CurrentControlSet\services\HxUpdateServiceInfo\ImagePath = ...jjs.exe`，
  `Start = 0x2 (AUTO_START)`。
- 0.38 秒后同一 exe 以 `NT AUTHORITY\SYSTEM` 被拉起 —— 这就是"注册成功"的验证。

## 工程/环境

### P12 · EVTX 默认读不了，要装 python-evtx 到 vendor
```powershell
python -m pip install --no-cache-dir --disable-pip-version-check --target vendor python-evtx
```
普通 `pip install` 会因沙箱禁止写缓存目录报 `[WinError 5] 拒绝访问`。

### P13 · Mordor 数据集的 pcap 放在加密 zip 里
- 密码：`infected`。`zipfile.ZipFile(...).open(name, pwd=b"infected")`。
- 不处理会直接 `RuntimeError: File is encrypted`。

### P14 · 大文件必须流式
- day1 Sysmon JSON 解压后 **376 MB**，day2 **1.67 GB**，都是单文件。
- `json.load()` 会直接吃掉几 GB 内存。逐行 `for line in f: json.loads(line)`。
- 内存参考：30 万行日志流式峰值 < 1 MB，pandas 会到 ~123 MB。

### P15 · 结论必须带"文件:字段=值"三元组
- 反例：`"发现 C2 通信"`。
- 正例：`"ssl.log server_name=192.168.0.4, 376 次; conn.log 10.0.1.6->192.168.0.4:8443"`。
- 判分点通常就卡在"有没有可复核的证据"。
