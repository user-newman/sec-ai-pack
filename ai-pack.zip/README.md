# 网安答题资料包（给 AI 用）

> 你在比赛里解题。这个包只放**解题需要的**：四篇方法手册、22 个 SKILL.md、4 个工具脚本。

## 先读这四篇，按顺序

| 顺序 | 文件 | 读完你能得到 |
|---|---|---|
| 1 | `00-ROUTER.md` | 什么题该读哪个 skill；哪些 skill 其实没用，别浪费时间 |
| 2 | `01-QUICKSTART.md` | 环境自检、装包写法、四步法、JSON 输出契约 |
| 3 | `03-PITFALLS.md` | 15 条实测陷阱，每条带真实数字——**下结论前必看** |
| 4 | `02-TOOLBOX.md` | 4 个脚本怎么用、有什么局限 |

## 目录

| 路径 | 内容 |
|---|---|
| `00-ROUTER.md` | 题目特征 → 读哪个 skill；实测评级 |
| `01-QUICKSTART.md` | 环境自检 / pip 写法 / 四步法 / 输出契约 |
| `02-TOOLBOX.md` | 脚本用法与局限 |
| `03-PITFALLS.md` | 15 条实测陷阱 |
| `skills/` | 23 个精选 skill，按 5 类：`01-network-traffic` `02-log-analysis` `03-malware` `04-reverse` `05-report` |
| `collections/` | 10 个集合的索引；`Anthropic-818` 只有 INDEX，按名字查 |
| `toolbox/` | `pcap2flows.py` `zeek_summary.py` `evtx_dump.py` `pe_info.py`；`toolbox/vendor/` 已预装 python-evtx，读 EVTX **断网可用** |

## 三条硬规则

1. **先跑 `toolbox/` 脚本，再读 skill**。脚本一秒出结构化结果，skill 只是判据手册。
2. **一次最多读 2 个 SKILL.md**。读多了会挤占上下文，反而漏细节——这是实测结论，不是建议。
3. **每个结论带「文件名 + 字段 + 数值」**。没有证据三元组的结论，判分时等于没答。

## 关于这批 skill 的实测结论（重要）

用真实 APT 数据（APT29、APT10、APT3）做过 6 组对照：**读 skill 的组并不比不读的组答得更好**，
6 个用例 0 胜 2 负 4 平。原因有三：知识和你已有的重叠；单份 2–45 KB 挤占上下文；
大量步骤写 `tshark -r` / `zeek -r` 而考场机没装这些工具。

**所以**：skill 当「检查清单」用，不要当「知识来源」用。
真正决定得分的是 `03-PITFALLS.md` 里的陷阱判据和 `toolbox/` 的脚本。

## 环境假设

Windows + Python 3.10+，**没有** tshark / zeek / wireshark / volatility / ghidra /
yara / pefile / scapy / pyshark / pandas。需要装包时：

```powershell
python -m pip install --no-cache-dir --disable-pip-version-check --target vendor <包名>
```

然后 `import sys; sys.path.insert(0, "vendor")`。

若考场有完整工具链，`skills/01-network-traffic/wireshark-analysis` 等可直接用原生命令。
