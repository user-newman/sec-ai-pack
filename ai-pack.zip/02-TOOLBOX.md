# 02 · TOOLBOX（4 个可直接调用的脚本）

> 全部只依赖 Python 3 标准库，专为「没有 tshark / zeek / pefile / Chainsaw」的考场准备。
> 统一用法：`python toolbox/<脚本> <目标> [--json]`，`--json` 输出便于二次处理。

## 1. `pcap2flows.py` — pcap 速查

```powershell
python toolbox/pcap2flows.py capture.pcap --top 15
python toolbox/pcap2flows.py capture.pcap --json > flows.json
```

**输出**：包数、会话数、时间跨度、Top 流（按包数）、Top 流（按载荷字节）、
目的端口分布、**TLS SNI 分布**、HTTP 请求行。

**实测价值**：8 MB / 7,284 包的 APT29 抓包，1 秒内出结果；
直接从 376 条 ClientHello 里读出 `SNI = 192.168.0.4`（C2 铁证）。
**它不绑端口**——8443、4433 上的 TLS 一样能解，这是最常见的漏判点。

**局限**：不支持 pcapng、IPv6 扩展头、IP 分片重组、TLS 解密。

## 2. `zeek_summary.py` — Zeek 日志汇总

```powershell
python toolbox/zeek_summary.py logs/ --top 12
python toolbox/zeek_summary.py logs/combined_zeek.log --json
```

**输出**：各日志类型事件数、访问关系 TopN、SNI 分布、DNS 分布、
HTTP 请求、**按字节排序的上传**、外网目的地（自动排除 RFC1918）。

**实测价值**：一眼看出 `PUT /webdav/OfficeSupplies.7z` 为 1,082,089 字节、
状态码 204（不是 200），以及 `10.0.1.6 -> 192.168.0.4:8443` 的 376 次连接。

**坑**：`combined_zeek.log` 是 `路径 \t ts \t uid \t {json}` 四段，
`individual_zeek_logs/*.log` 是纯 JSON 行。脚本已兼容两种。

## 3. `evtx_dump.py` — 读 EVTX（自动装依赖）

```powershell
python toolbox/evtx_dump.py security.evtx --event-id 1,7,8,13
python toolbox/evtx_dump.py security.evtx --json --limit 50
```

**降级策略**：本包已**预装 python-evtx 到 `toolbox/vendor/`**（1.3 MB），
脚本会自己把它加进 `sys.path`，**断网也能用**。
若 vendor 被删，脚本会自动尝试
`pip install --no-cache-dir --target vendor python-evtx`；
仍失败则退化为可打印字符串 + UTF-16 字符串提取（仍能拿到路径/命令行/哈希）。

**实测价值**：11 条记录的 APT10 样本，直接输出
`EID 7: jjs.exe 加载同目录 jli.dll`、`EID 13: services.exe 写 HxUpdateServiceInfo 服务`。

**注意**：`pip install` 不加 `--no-cache-dir` 会因沙箱禁止写缓存目录而失败（`[WinError 5]`）。

## 4. `pe_info.py` — PE 静态速查

```powershell
python toolbox/pe_info.py suspect.exe
python toolbox/pe_info.py suspect.exe --json
```

**输出**：架构/时间戳/入口点、节表（含每节**熵**）、导入 DLL 与函数、
**可疑导入**、可疑字符串、加壳迹象、是否有签名目录。

**实测价值**：对 `recycler.exe` 一眼看出
`entropy(.text)=6.70`（无壳）、导入仅 `KERNEL32/MSVCRT/ADVAPI32/USER32/OLEAUT32`、
**无 ws2_32 / CreateProcess / Reg\* / WriteProcessMemory** —— 由此判"不是 dropper"，
而不是被 `VirtualAlloc` 误导。

**局限**：不解析资源目录里的版本信息（`pe_info` 只给"有无签名"），
需要版本字符串时用字符串搜索 `OriginalFilename` / `CompanyName`。

---

## 组合用法：一条 APT 题的 60 秒开局

```powershell
# 1) 环境
python -c "import importlib.util as u;print([m for m in ['Evtx','pefile','scapy','pyshark','pandas'] if u.find_spec(m)])"

# 2) 看数据长什么样
Get-ChildItem -Recurse -File | Group-Object Extension | Sort-Object Count -Descending

# 3) 按类型跑脚本
python toolbox/pcap2flows.py  *.pcap
python toolbox/zeek_summary.py zeek/  --top 20
python toolbox/evtx_dump.py    *.evtx --event-id 1,7,8,13
python toolbox/pe_info.py      *.exe

# 4) 拿输出直接对照 03-PITFALLS.md 的 15 条判据
```
