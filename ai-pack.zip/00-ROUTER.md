# 00 · ROUTER（先读这一页再选题）

> 本页回答三件事：**这题该读哪个 skill**、**哪些 skill 其实可以跳过**、**读之前先跑什么脚本**。
> 评级来自真实 APT 数据的 A/B 实测（APT29 day1/day2、APT10 EVTX、APT3 样本），不是转载的自我描述。

## 一、三步走

1. **先跑环境自检**（`01-QUICKSTART.md` 第 0 节），确定哪些命令行工具真的存在。
2. **按下面的表选题**，一次只读 1–2 个 skill，不要全量加载。
3. **先跑 `toolbox/` 里的脚本拿到结构化输出**，再读 skill 里的判据，最后按 `03-PITFALLS.md` 复核。

## 二、题目特征 → 先读什么

| 题目给的东西 | 先跑 | 再读 | 关键判据 |
|---|---|---|---|
| `.pcap` / `.cap` | `toolbox/pcap2flows.py` | `skills/01-network-traffic/wireshark-analysis`（过滤器语法） | 五元组 TopN、SNI、上传字节 |
| Zeek `*.log`（JSONL） | `toolbox/zeek_summary.py` | `skills/01-network-traffic/analyzing-network-traffic-for-incidents` | SNI=IP、无 SNI 的 TLS、`request_body_len` |
| Windows `.evtx` | `toolbox/evtx_dump.py` | `skills/02-log-analysis/extracting-windows-event-logs-artifacts` | EID 1/7/8/13 的 Image/ParentImage/RuleName |
| Sysmon `.jsonl` / JSON | `toolbox/zeek_summary.py` 不适用，直接 Python 流式 | 同上 + `03-PITFALLS.md` P6/P7 | Message 是 `Key: Value` 文本，不是 XML |
| Web 访问日志（Apache/Nginx） | Python 流式统计 | `skills/02-log-analysis/log-audit`（中文，44 条 ATT&CK 规则） | 状态码 + 响应字节 + UA 指纹 |
| Linux `auth.log`/`syslog` | Python 流式统计 | `skills/02-log-analysis/log-analysis` | 爆破成功要看到"登录后行为" |
| PE / 可疑样本 | `toolbox/pe_info.py` | `skills/03-malware/malware-analysis-static` | 版本资源、导入表缺失项、熵 |
| 需要反汇编/反编译 | 无（本机无 IDA/Ghidra） | `skills/04-reverse/reverse-engineer-anything` | 先静态字符串+导入，再谈指令级 |
| APT 综合狩猎 / 多阶段 | 先按数据源拆成上面几行 | `skills/01-network-traffic/analyzing-network-traffic-for-incidents` | 投递→横向→C2→外泄 四段闭环 |
| **题目要求写报告，且格式按公文** | 直接写 `template.json` 再跑生成器 | `skills/05-report/gongwen-report` | 页边距 37/35/28/26、正文 3 号仿宋、行距 28.8pt；跑 `gen_gongwen.py` 出 docx |
| 红队 / 反取证视角 | — | `collections/Claude-Red`（含 offensive-anti-forensics） | 日志清除、时间戳篡改的痕迹方向 |

## 三、实测评级（重要）

**测试条件**：6 个真实 APT 用例（APT29 day1/day2、APT10 EVTX、APT3 样本），
同一模型、同一题面、同样的环境提示，唯一变量是"是否阅读 skill"。

| skill | 静态分 | 实测增量 | 结论 |
|---|---|---|---|
| `performing-network-traffic-analysis-with-zeek` | 70 | **−1** | 对照组更细。方法对，但没写"SNI=IP"这一关键判据 |
| `extracting-windows-event-logs-artifacts` | 70 | **0** | 与模型先验高度重叠 |
| `log-analysis`（dfir-skills） | 45 | **0** | 能答对，但 EVTX 解析靠 agent 自己想到装 python-evtx |
| `malware-analysis-static`（guelfoweb） | 90 | **0** | 两组都正确识别 7-Zip，未掉陷阱 |
| `analyzing-network-traffic-for-incidents` | 90 | **≤0** | 对照组多找到 `nexus.passport.com` 认证链 |
| `performing-network-traffic-analysis-with-tshark` | **0** | 见报告 | 只有 65 行、假设 tshark/pyshark 存在、无兜底无输出契约 |

**总判断**：这 6 个 skill 对**已经很强的模型**没有可测量的准确率提升；
它们的主要价值是**清单完整性**和**术语统一**，不是"知识增量"。

## 四、什么时候**不要**读 skill

- 题目是单文件、结构清晰（如只有一个 pcap）：直接跑 `toolbox/` 脚本，读完 skill 反而挤占上下文。
- skill 里写的命令在你机器上不存在（tshark/zeek/volatility/ghidra）：不要照抄，直接看 `01-QUICKSTART.md` 的兜底表。
- 你已经能说出"这题的判据是什么"：说明不需要它了，直接作答并去 `03-PITFALLS.md` 复核。

## 五、真正带来提升的三件事（实测支撑）

1. **环境兜底**：C4 的 EVTX 只有装进 `vendor` 的 python-evtx 才读得动；C2 的 pcap 只能手写 struct 解析。
2. **输出契约**：所有 12 次作答都靠固定的 JSON 骨架保持可比、可判分。
3. **陷阱知识**：`recycler.exe` 是改名 7-Zip（不是木马）、`.scr` 文件名藏 U+202E、C2 的 SNI 写成 IP——
   这三条都是"看起来像 A 其实是 B"，写进 `03-PITFALLS.md` 比写进任何 skill 都值钱。
